<?php

/*
* 2014-2015 IONPay Networks
* Do not edit this code, if you wish to upgrade PrestaShop to newer
* versions in the future or customize PrestaShop for your
* needs please refer to http://www.ionpay.net for more information.
*
*  @author IONPay <info@ionpay.net>
*  @copyright  2014-2015 IONPay Networks
*  International Registered Trademark & Property of IONPay Networks
*/

if (!defined('_PS_VERSION_'))
    exit;

class Nicepay extends PaymentModule {



    private $_html = '';
    private $_postErrors = array();
    public $username;
    public $api_key;

    
    public function __construct() {
        $this->name = 'nicepay';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->author = 'NICEPay';
        $this->controllers = array('payment', 'validation', 'notificationHandler');

        $this->currencies = true;
        $this->currencies_mode = 'checkbox';




        $config = Configuration::getMultiple(array('NICEPAY_IMID', 'NICEPAY_MERCHANT_KEY', 'IONPAY_ORDER_STATE_ID'));

        if (!empty($config['NICEPAY_IMID']))
            $this->username = $config['NICEPAY_IMID'];
        if (!empty($config['NICEPAY_MERCHANT_KEY']))
            $this->api_key = $config['NICEPAY_MERCHANT_KEY'];
        if (!empty($config['IONPAY_ORDER_STATE_ID']))
            $this->api_key = $config['IONPAY_ORDER_STATE_ID'];

        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->l('NICEPay');
        $this->description = $this->l('This module allows you TEST NICEPay Credit Card Payment.');
        $this->confirmUninstall = $this->l('Are you sure about removing these details?');



        if (!isset($this->username) || !isset($this->api_key))
            $this->warning = $this->l('Merchant ID and API_KEY details must be configured before using this module.');
        if (!count(Currency::checkPaymentCurrencies($this->id)))
            $this->warning = $this->l('No currency has been set for this module.');

        



    }

    public function isOldPrestashop()
    {
        
        return version_compare(Configuration::get('PS_VERSION_DB'), '1.5') == -1;
    }

    public function install() {
       
        $order_state = new OrderStateCore();
        $order_state->name = array((int)Configuration::get('PS_LANG_DEFAULT') => 'Awaiting NICEPay payment');;
        $order_state->module_name = 'nicepay';
        if ($this->isOldPrestashop()) {
            $order_state->color = '#0000FF';
        } else
        {
            $order_state->color = 'RoyalBlue';
        }

        $order_state->unremovable = false;
        $order_state->add();
        Configuration::updateValue('IONPAY_ORDER_STATE_ID', $order_state->id);
        $languages = Language::getLanguages(true);
        foreach ($languages as $language) {
            if ($language['iso_code'] == 'id') {
                //Mandiri Email Template
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf.html');
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf.txt');
                //Permata Email Template
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_permata.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_permata.html');
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_permata.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_permata.txt');
                //BII Email Template
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_bii.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bii.html');
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_bii.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bii.txt');
                //BNI Email Template
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_bni.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bni.html');
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_bni.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bni.txt');

                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_bca.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bca.html');
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_bca.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bca.txt');

                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_cimb.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_cimb.html');
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_cimb.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_cimb.txt');


                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_hana.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_hana.html');
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_hana.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_hana.txt');


                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_bri.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bri.html');
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_bri.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bri.txt');

                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_danamon.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_danamon.html');
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_danamon.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_danamon.txt');

            }else {
                //Mandiri Email Template
                copy(dirname(__FILE__) . '/mails/en/nicepay_order_conf.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf.html');
                copy(dirname(__FILE__) . '/mails/en/nicepay_order_conf.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf.txt');
                //Permata Email Template
                copy(dirname(__FILE__) . '/mails/en/nicepay_order_conf_permata.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_permata.html');
                copy(dirname(__FILE__) . '/mails/en/nicepay_order_conf_permata.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_permata.txt');
                //BII Email Template
                copy(dirname(__FILE__) . '/mails/en/nicepay_order_conf_bii.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bii.html');
                copy(dirname(__FILE__) . '/mails/en/nicepay_order_conf_bii.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bii.txt');
                //BNI Email Template
                copy(dirname(__FILE__) . '/mails/en/nicepay_order_conf_bni.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bni.html');
                copy(dirname(__FILE__) . '/mails/en/nicepay_order_conf_bni.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bni.txt');

                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_bca.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bca.html');
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_bca.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bca.txt');

                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_cimb.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_cimb.html');
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_cimb.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_cimb.txt');


                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_hana.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_hana.html');
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_hana.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_hana.txt');


                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_bri.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bri.html');
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_bri.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_bri.txt');

                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_danamon.html',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_danamon.html');
                copy(dirname(__FILE__) . '/mails/id/nicepay_order_conf_danamon.txt',_PS_MAIL_DIR_.'/'.strtolower($language['iso_code']).'/nicepay_order_conf_danamon.txt');


            }
        }

        if (!parent::install() || !$this->registerHook('payment') || !$this->registerHook('paymentReturn'))
            return false;
        return true;
    }

    public function uninstall() {
       
    
        $ionpay_payment_waiting_order_state_id = Configuration::get('IONPAY_ORDER_STATE_ID');
        if ($ionpay_payment_waiting_order_state_id)
        {
            $order_state = new OrderStateCore($ionpay_payment_waiting_order_state_id);
            $order_state->delete();
        }
        if (!Configuration::deleteByName('NICEPAY_IMID') || !Configuration::deleteByName('NICEPAY_MERCHANT_KEY') || !parent::uninstall())
            return false;
        return true;
    }

    private function _postValidation() {
        

        if (Tools::isSubmit('btnSubmit')) {
            if (!Tools::getValue('NICEPAY_IMID'))
                $this->_postErrors[] = $this->l('Merchant ID is required.');
            elseif (!Tools::getValue('NICEPAY_MERCHANT_KEY'))
                $this->_postErrors[] = $this->l('Api key is required.');
        }
    }

    private function _postProcess() {
       
    
        
        if (Tools::isSubmit('btnSubmit')) {
            Configuration::updateValue('NICEPAY_IMID', Tools::getValue('NICEPAY_IMID'));
            Configuration::updateValue('NICEPAY_MERCHANT_KEY', Tools::getValue('NICEPAY_MERCHANT_KEY'));
            Configuration::updateValue('NICEPAY_PAYMENT_METHOD', Tools::getValue('NICEPAY_PAYMENT_METHOD'));
        }
        $this->_html .= $this->displayConfirmation($this->l('Settings updated'));
    }

    private function _displayIonpay() {
       
        return $this->display(__FILE__, 'infos.tpl');
    }

    public function getContent() {
       
    
        if (Tools::isSubmit('btnSubmit')) {
            $this->_postValidation();
            if (!count($this->_postErrors))
                $this->_postProcess();
            else
                foreach ($this->_postErrors as $err)
                    $this->_html .= $this->displayError($err);
        } else {
            $this->_html .= '<br />';
        }

        $this->_html .= $this->_displayIonpay();
        $this->_html .= $this->renderForm();

        return $this->_html;
    }

    public function hookPayment($params) {
        
    
        if (!$this->active)
            return;
        if (!$this->checkCurrency($params['cart']))
            return;

        $this->context->controller->addCSS($this->_path . 'nicepay.css', 'all');
        $this->smarty->assign(array(
            'this_path' => $this->_path,
            'this_path_bw' => $this->_path,
            'this_path_ssl' => Tools::getShopDomainSsl(true, true) . __PS_BASE_URI__ . 'modules/' . $this->name . '/'
        ));
        return $this->display(__FILE__, 'payment.tpl');
    }

    public function hookPaymentReturn($params) {
        
        if (!$this->active)
            return;

        return $this->display(__FILE__, 'payment_return.tpl');
    }

    public function checkCurrency($cart) {
       

    
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);

        if (is_array($currencies_module))
            foreach ($currencies_module as $currency_module)
                if ($currency_order->id == $currency_module['id_currency'])
                    return true;
        return false;
    }

    public function renderForm() {
       
    
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('NICEPAY API DETAILS'),
                    'icon' => 'icon-envelope'
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->l('MID'),
                        'name' => 'NICEPAY_IMID',
                        'desc' => $this->l('Fill this field with MID provided by NICEPay')
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('API KEY'),
                        'name' => 'NICEPAY_MERCHANT_KEY',
                        'desc' => $this->l('Fill this field with API Key provided by NICEPay')
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('PAYMENT METHOD'),
                        'name' => 'NICEPAY_PAYMENT_METHOD',
                        'desc' => $this->l('Select payment method which match with your system'),
                        'options' => array(
                            'query' => array(
                                array(
                                    'id_option' => "CC",
                                    'name' => 'Credit Card'
                                ),
                                array(
                                    'id_option' => "VA",
                                    'name' => 'Bank Transfer'
                                ),
                                array(
                                    'id_option' => "ALL_METHOD",
                                    'name' => 'Credit Card and Bank Transfer'
                                ),
                            ),
                            'id' => 'id_option',
                            'name' => 'name'
                        ),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int) Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $this->fields_form = array();
        $helper->id = (int) Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmit';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false) . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }

    public function getConfigFieldsValues() {
       
    
        return array(
            'NICEPAY_IMID' => Tools::getValue('NICEPAY_IMID', Configuration::get('NICEPAY_IMID')),
            'NICEPAY_MERCHANT_KEY' => Tools::getValue('NICEPAY_MERCHANT_KEY', Configuration::get('NICEPAY_MERCHANT_KEY')),
            'NICEPAY_PAYMENT_METHOD' => Tools::getValue('NICEPAY_PAYMENT_METHOD', Configuration::get('NICEPAY_PAYMENT_METHOD')),
        );
    }

}
