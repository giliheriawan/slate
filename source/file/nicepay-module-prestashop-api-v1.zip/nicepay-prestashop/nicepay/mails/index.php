<?php
/*
* 2014-2015 IONPay Networks
* Do not edit this code, if you wish to upgrade PrestaShop to newer
* versions in the future or customize PrestaShop for your
* needs please refer to http://www.ionpay.net for more information.
*
*  @author IONPay <info@ionpay.net>
*  @copyright  2014-2015 IONPay Networks
*  International Registered Trademark & Property of IONPay Networks
*/

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
						
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
						
header("Location: ../");
exit;