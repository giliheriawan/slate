<?php

/*
* 2014-2015 IONPay Networks
* Do not edit this code, if you wish to upgrade PrestaShop to newer
* versions in the future or customize PrestaShop for your
* needs please refer to http://www.ionpay.net for more information.
*
*  @author IONPay Networks <info@ionpay.net>
*  @copyright  2014-2015 IONPay Networks
*  International Registered Trademark & Property of IONPay Networks
*/

// Include Config File
include_once "lib/NicepayLib.php";

class NicepayValidationModuleFrontController extends ModuleFrontController {


    public function generateReference(){
        $micro_date = microtime();
        $date_array = explode(" ",$micro_date);
        $date = date("YmdHis",$date_array[1]);
        $date_array[0] = preg_replace('/[^\p{L}\p{N}\s]/u', '', $date_array[0]);
        return "Ref".$date.$date_array[0].rand(100,999);
    }

    /**
     * @see FrontController::postProcess()
     */
    public function postProcess() {

        $cart = $this->context->cart;



        if ($cart->id == 0 || $cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active)
            Tools::redirect('index.php?controller=order&step=1');

        // print_r($cart); exit;

        // Check that this payment option is still available in case the customer changed his address just before the end of the checkout process
        $authorized = false;
        foreach (Module::getPaymentModules() as $module)
            if ($module['name'] == 'nicepay') {
                $authorized = true;
                break;
            }
        if (!$authorized)
            die($this->module->l('This payment method is not available.', 'validation'));

        $customer = new Customer($cart->id_customer);
        if (!Validate::isLoadedObject($customer))
            Tools::redirect('index.php?controller=order&step=1');

        // Prepare Parameters
        $domain = Tools::getShopDomainSsl(true, true);

        $products = $cart->getProducts(true);

        

        foreach ($products as $product => $items) {
       // echo "Key: $product; Value: $item<br />\n";
            $item[] = array(
                'img_url' => $items['name'],
                'goods_name' => $items['name'],
                'goods_detail' => $items['description_short'],
                // 'goods_amt' => $items['total_wt']
                'goods_amt' => round($items['total_wt'])
            );
        }

        $cartData = array(
            "count" => count($products),
            "item" => $item
        );

        // print_r(round($cart->getOrderTotal(true, Cart::BOTH)));

        // //  print_r((float)$cart->getOrderTotal(true, Cart::BOTH);); 

        //  exit;

        $order_status = (int)Configuration::get('IONPAY_ORDER_STATE_ID');
       // $order_total = (float)$cart->getOrderTotal(true, Cart::BOTH);
       $order_total = round($cart->getOrderTotal(true, Cart::BOTH));



        if(Tools::getValue('payMethod') && Tools::getValue('payMethod') == '02'){
            $labelPayment = "NICEPay Virtual Account";
            $message = 'Cara Transfer';
        }elseif(Tools::getValue('payMethod') && Tools::getValue('payMethod') == '01'){
            $labelPayment = "NICEPay Credit Card";
            $message = null;
        }




        /* echo "<pre>";
        print_r($cart);
        echo "</pre>";
        exit; */

        //Create Order
        $this->module->validateOrder($cart->id, $order_status, $order_total, $labelPayment, $message, array(), null, false, $cart->secure_key);
        $id_order =$this->module->currentOrder;
        



        $nicepay = new NicepayLib();

        $addressInvoice = new Address($cart->id_address_invoice);
        $billingNm = $addressInvoice->firstname." ".$addressInvoice->lastname;
        $billingPhone = $addressInvoice->phone;
        $billingEmail = $customer->email;
        $billingAddr = $addressInvoice->address1;
        $billingCity = $addressInvoice->city;
        $billingState = $addressInvoice->city;
        $billingPostCd = $addressInvoice->postcode;
        $billingCountry = $addressInvoice->country;

        $addressDelivery = new Address($cart->id_address_delivery);
        $deliveryNm = $addressDelivery->firstname." ".$addressDelivery->lastname;
        $deliveryPhone = $addressDelivery->phone;
        $deliveryEmail = $customer->email;
        $deliveryAddr = $addressDelivery->address1;
        $deliveryCity = $addressDelivery->city;
        $deliveryState = $addressDelivery->city;
        $deliveryPostCd = $addressDelivery->postcode;
        $deliveryCountry = $addressDelivery->country;

        /*
     * ____________________________________________________________
     *
     * Virtual Account Payment Method
     * ____________________________________________________________
     */

        

        
        if(Tools::getValue('payMethod') && Tools::getValue('payMethod') == '02' && Tools::getValue('bankCd'))
        {
            $bankCd         = Tools::getValue('bankCd');
            $dateNow        = date('Ymd');
            $vaExpiryDate   = date('Ymd', strtotime($dateNow . ' +1 day')); // Set VA expiry date +1 day (optional)
            // Populate Mandatory parameters to send
            $nicepay->set('payMethod', '02');
            $nicepay->set('currency', 'IDR');
            $nicepay->set('cartData', json_encode($cartData));
            $nicepay->set('amt', $order_total); // Total gross amount
            $order = new Order($id_order);
            $nicepay->set('referenceNo', $id_order);
            $nicepay->set('description', 'Payment of order '.$order->getUniqReference());
            $nicepay->set('bankCd', $bankCd);
            $nicepay->callBackUrl = $domain . __PS_BASE_URI__ . 'index.php?controller=history';
            $nicepay->set('billingNm', $billingNm); // Customer name
            $nicepay->set('billingPhone', $billingPhone); // Customer phone number
            $nicepay->set('billingEmail', $billingEmail);
            $nicepay->set('billingAddr', $billingAddr);
            $nicepay->set('billingCity', $billingCity);
            $nicepay->set('billingState', $billingState);
            $nicepay->set('billingPostCd', $billingPostCd);
            $nicepay->set('billingCountry', $billingCountry);
            $nicepay->set('deliveryNm', $deliveryNm); // Delivery name
            $nicepay->set('deliveryPhone', $deliveryPhone);
            $nicepay->set('deliveryEmail', $deliveryEmail);
            $nicepay->set('deliveryAddr', $deliveryAddr);
            $nicepay->set('deliveryCity', $deliveryCity);
            $nicepay->set('deliveryState', $deliveryState);
            $nicepay->set('deliveryPostCd', $deliveryPostCd);
            $nicepay->set('deliveryCountry', $deliveryCountry);
            $nicepay->set('vacctVaildDt', $vaExpiryDate); // Set VA expiry date example: +1 day
            $nicepay->set('vacctVaildTm', date('His')); // Set VA Expiry Time
            $nicepay->set('dbProcessUrl', Context::getContext()->link->getModuleLink('nicepay', 'notificationHandler'));

            $response = $nicepay->requestVA();    


        if (isset($response->resultCd) && $response->resultCd == "0000") {
            //Set Bank Name
            $bankNameArr = array(
                "BMRI" => "Mandiri",
                "BBBA" => "Permata Bank",
                "IBBK" => "Maybank BII",
                "BNIN" => "BNI",
                 "CENA" => "BCA",
                  "BNIA" => "CIMB",
                   "HNBN" => "KEB Hana Bank",
                    "BRIN" => "BRI",
                     "BDIN" => "DANAMON",
            );
            //Change format date
            $getYear = substr($vaExpiryDate,0,4);
            $getMonth = substr($vaExpiryDate,4,2);
            $getDay = substr($vaExpiryDate,6,2);
            $newDate = $getDay."-".$getMonth."-".$getYear;
            //Set Extra Vars Email
            $extra_vars = array(
                '{tXid}' => $response->tXid,
                '{callbackUrl}' => $response->callbackUrl,
                '{description}' => $response->description,
                '{payment_date}' => $response->transDt,
                '{payment_time}' => $response->transTm,
                '{virtual_account}' => $response->bankVacctNo,
                '{result_code}' => $response->resultCd,
                '{result_message}' => $response->resultMsg,
                '{reference_no}' => $response->referenceNo,
                '{bankCd}' => Tools::getValue('bankCd'),
                '{bankName}' => $bankNameArr[Tools::getValue('bankCd')],
                '{expDate}' => $newDate,
                '{paymentMethod}' => $response->payMethod
            );
            $this->nicepayOrderConfEmail($response->referenceNo, $order_status, $extra_vars);
            //Set Template Callback
            $this->context->smarty->assign(array(
                'tXid' => $response->tXid,
                'callbackUrl' => $response->callbackUrl,
                'description' => $response->description,
                'payment_date' => $response->transDt,
                'payment_time' => $response->transTm,
                'virtual_account' => $response->bankVacctNo,
                'result_code' => $response->resultCd,
                'result_message' => $response->resultMsg,
                'reference_no' => $response->referenceNo,
                'bankCd' => Tools::getValue('bankCd'),
                'bankName' => $bankNameArr[Tools::getValue('bankCd')],
                'expDate' => $newDate,
                'paymentMethod' => $response->payMethod
            ));
          
            //$this->module->validateOrder($cart->id, Configuration::get('PS_OS_BANKWIRE'), $total, $this->module->displayName, NULL, $mailVars, (int)$currency->id, false, $customer->secure_key);
           // Tools::redirect('index.php?controller=order-confirmation&id_cart='.$cart->id.'&id_module='.$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key);

            // Tools::redirect('index.php/module/nicepay/validation');
             // Tools::redirect('index.php?controller=order-confirmation');


             $this->setTemplate('validation.tpl');

        } elseif(isset($response->resultCd)) {
                // API data not correct, you can redirect back to checkout page or echo error message.
                // In this sample, we echo error message
        /*         echo "<pre>";
                echo "result code       :".$response->resultCd."\n";
                echo "result message    :".$response->resultMsg."\n";
                echo "</pre>"; */
            $this->context->smarty->assign(array(
            'result_code' => $response->resultCd,
            'result_message' => $response->resultMsg
            ));
            $this->setTemplate('error_message.tpl');
        } else {
                // Timeout, you can redirect back to checkout page or echo error message.
                // In this sample, we echo error message
                /* echo "<pre>Connection Timeout. Please Try again.</pre>"; */
                $this->context->smarty->assign(array(
                    'connect_timeout' => 'Connection Timeout. Please Try again.'
                ));
                $this->setTemplate('connect_timout.tpl');
        }

    }
    /*
     * ____________________________________________________________
     *
     * Credit Card Payment Method
     * ____________________________________________________________
     */
        elseif(Tools::getValue('payMethod') && Tools::getValue('payMethod') == '01')
        {
            // Populate Mandatory parameters to send
            $nicepay->set('payMethod', '01');
            $nicepay->set('currency', 'IDR');
            $nicepay->set('cartData', json_encode($cartData));
            $nicepay->set('amt', $order_total); // Total gross amount //
            //$order = new Order($id_order);
            //$nicepay->set('referenceNo', $order->getUniqReference());
            $nicepay->set('referenceNo', $id_order);
            /* $nicepay->set('referenceNo', $this->generateReference()); */ // Invoice Number or Referenc Number Generated by merchant
            $nicepay->set('description', 'Payment of invoice No '.$id_order); // Transaction description
            
            $nicepay->callBackUrl = $domain . __PS_BASE_URI__ . 'index.php?controller=history'; // Transaction description
            $nicepay->set('billingNm', $billingNm); // Customer name
            $nicepay->set('billingPhone', $billingPhone); // Customer phone number
            $nicepay->set('billingEmail', $billingEmail); //
            $nicepay->set('billingAddr', $billingAddr);
            $nicepay->set('billingCity', $billingCity);
            $nicepay->set('billingState', $billingState);
            $nicepay->set('billingPostCd', $billingPostCd);
            $nicepay->set('billingCountry', $billingCountry);
            $nicepay->set('deliveryNm', $deliveryNm); // Delivery name
            $nicepay->set('deliveryPhone', $deliveryPhone);
            $nicepay->set('deliveryEmail', $deliveryEmail);
            $nicepay->set('deliveryAddr', $deliveryAddr);
            $nicepay->set('deliveryCity', $deliveryCity);
            $nicepay->set('deliveryState', $deliveryState);
            $nicepay->set('deliveryPostCd', $deliveryPostCd);
            $nicepay->set('deliveryCountry', $deliveryCountry);
            $nicepay->set('dbProcessUrl', Context::getContext()->link->getModuleLink('nicepay', 'notificationHandler'));
            // Send Data
            $response = $nicepay->chargeCard();
            // Response from NICEPAY
            if (isset($response->data->resultCd) && $response->data->resultCd == "0000") {
                  header("Location: ".$response->data->requestURL."?tXid=".$response->tXid);
    //            please save tXid in your database
    //            echo "<pre>";
    //            echo "tXid              : $response->tXid\n";
    //            echo "API Type          : $response->apiType\n";
    //            echo "Request Date      : $response->requestDate\n";
    //            echo "Response Date     : $response->requestDate\n";
    //            echo "</pre>";
            } elseif(isset($response->data->resultCd)) {
                // API data not correct or error happened in bank system, you can redirect back to checkout page or echo error message.
                // In this sample, we echo error message
                // header("Location: "."http://example.com/checkout.php");
                echo "<pre>";
                echo "result code       : ".$response->data->resultCd."\n";
                echo "result message    : ".$response->data->resultMsg."\n";
    //            echo "requestUrl        : ".$response->data->requestURL."\n";
                echo "</pre>";
            } else {
                // Timeout, you can redirect back to checkout page or echo error message.
                // In this sample, we echo error message
                // header("Location: "."http://example.com/checkout.php");
                echo "<pre>Connection Timeout. Please Try again.</pre>";
            }
        }
        // Unknown
        else {
            echo "Unknown method";
        }
    }

    public function nicepayOrderConfEmail($order_id, $id_order_state, $extra_vars = array()){
        $order = new Order($order_id);
        if ($id_order_state != Configuration::get('PS_OS_ERROR') && $id_order_state != Configuration::get('PS_OS_CANCELED') && $this->context->customer->id) {
            $invoice = new Address($order->id_address_invoice);
            $delivery = new Address($order->id_address_delivery);
            $delivery_state = $delivery->id_state ? new State($delivery->id_state) : false;
            $invoice_state = $invoice->id_state ? new State($invoice->id_state) : false;
            $virtual_product = false;
            $data = array(
                '{firstname}' => $this->context->customer->firstname,
                '{lastname}' => $this->context->customer->lastname,
                '{email}' => $this->context->customer->email,
                '{delivery_company}' => $delivery->company,
                '{delivery_firstname}' => $delivery->firstname,
                '{delivery_lastname}' => $delivery->lastname,
                '{delivery_address1}' => $delivery->address1,
                '{delivery_address2}' => $delivery->address2,
                '{delivery_city}' => $delivery->city,
                '{delivery_postal_code}' => $delivery->postcode,
                '{delivery_country}' => $delivery->country,
                '{delivery_state}' => $delivery->id_state ? $delivery_state->name : '',
                '{delivery_phone}' => ($delivery->phone) ? $delivery->phone : $delivery->phone_mobile,
                '{delivery_other}' => $delivery->other,
                '{invoice_company}' => $invoice->company,
                '{invoice_vat_number}' => $invoice->vat_number,
                '{invoice_firstname}' => $invoice->firstname,
                '{invoice_lastname}' => $invoice->lastname,
                '{invoice_address2}' => $invoice->address2,
                '{invoice_address1}' => $invoice->address1,
                '{invoice_city}' => $invoice->city,
                '{invoice_postal_code}' => $invoice->postcode,
                '{invoice_country}' => $invoice->country,
                '{invoice_state}' => $invoice->id_state ? $invoice_state->name : '',
                '{invoice_phone}' => ($invoice->phone) ? $invoice->phone : $invoice->phone_mobile,
                '{invoice_other}' => $invoice->other,
                '{order_name}' => $order->getUniqReference(),
                '{date}' => Tools::displayDate(date('Y-m-d H:i:s'), null, 1),
                '{carrier}' => ($virtual_product || !isset($carrier->name)) ? Tools::displayError('No carrier') : $carrier->name,
                '{payment}' => Tools::substr($order->payment, 0, 32),
                '{total_paid}' => Tools::displayPrice($order->total_paid, $this->context->currency, false),
                '{total_products}' => Tools::displayPrice(Product::getTaxCalculationMethod() == PS_TAX_EXC ? $order->total_products : $order->total_products_wt, $this->context->currency, false),
                '{total_discounts}' => Tools::displayPrice($order->total_discounts, $this->context->currency, false),
                '{total_shipping}' => Tools::displayPrice($order->total_shipping, $this->context->currency, false),
                '{total_wrapping}' => Tools::displayPrice($order->total_wrapping, $this->context->currency, false),
                '{total_tax_paid}' => Tools::displayPrice(($order->total_products_wt - $order->total_products) + ($order->total_shipping_tax_incl - $order->total_shipping_tax_excl), $this->context->currency, false));
            if(is_array($extra_vars)){
                $data = array_merge($data, $extra_vars);
            }
            if($extra_vars["{bankCd}"] == "BMRI"){ //Mandiri
                $tplName = "nicepay_order_conf";
            }else if($extra_vars["{bankCd}"] == "BBBA"){ //Permata Bank
                $tplName = "nicepay_order_conf_permata";
            }else if($extra_vars["{bankCd}"] == "IBBK"){ //Maybank BII
                $tplName = "nicepay_order_conf_bii";
            }else if($extra_vars["{bankCd}"] == "BNIN"){ //BNI
                $tplName = "nicepay_order_conf_bni";
            }else if($extra_vars["{bankCd}"] == "CENA"){ //BCA
                $tplName = "nicepay_order_conf_bca";
            }else if($extra_vars["{bankCd}"] == "BNIA"){ //CIMB
                $tplName = "nicepay_order_conf_cimb";
            }else if($extra_vars["{bankCd}"] == "HNBN"){ //HANA
                $tplName = "nicepay_order_conf_hana";
            }else if($extra_vars["{bankCd}"] == "BRIN"){ //BRI
                $tplName = "nicepay_order_conf_bri";
            }else if($extra_vars["{bankCd}"] == "BDIN"){ //DANAMON
                $tplName = "nicepay_order_conf_danamon";
            }
            $titleMail = "Order Detail ".$order->getUniqReference();
            if (Validate::isEmail($this->context->customer->email)) {
                Mail::Send(
                    (int)$order->id_lang,
                    $tplName,
                    Mail::l($titleMail, (int)$order->id_lang),
                    $data,
                    $this->context->customer->email,
                    $this->context->customer->firstname.' '.$this->context->customer->lastname,
                    null,
                    null,
                    null,
                    null, _PS_MAIL_DIR_, false, (int)$order->id_shop
                );
            }
        }

    }
}?>