<?php
/*
* 2014-2015 IONPay Networks
* Do not edit this code, if you wish to upgrade PrestaShop to newer
* versions in the future or customize PrestaShop for your
* needs please refer to http://www.ionpay.net for more information.
*
*  @author IONPay <info@ionpay.net>
*  @copyright  2014-2015 IONPay Networks
*  International Registered Trademark & Property of IONPay Networks
*/

include_once "lib/NicepayLib.php";
/** * @since 1.5.0 */
class NicepayNotificationHandlerModuleFrontController extends ModuleFrontController{
    public $ssl = true;
    public $display_column_left = false;
    /**     * @see FrontController::initContent()     */
    public function initContent(){

        $nicepay = new NicepayLib();
        // Listen for parameters passed
        $pushParameters = array(
            'tXid',
            'referenceNo',
            'amt',
            'merchantToken'
        );        
        $nicepay->extractNotification($pushParameters);

        $iMid               = $nicepay->iMid;
        $tXid               = $nicepay->getNotification('tXid');
        $referenceNo        = $nicepay->getNotification('referenceNo');
        $amt                = $nicepay->getNotification('amt');        
        $pushedToken        = $nicepay->getNotification('merchantToken');

        $nicepay->set('tXid', $tXid);
        $nicepay->set('referenceNo', $referenceNo);
        $nicepay->set('amt', $amt);
        $nicepay->set('iMid',$iMid);

        $merchantToken = $nicepay->merchantTokenC();
        $nicepay->set('merchantToken', $merchantToken);

        // <RESQUEST to NICEPAY>

        $paymentStatus = $nicepay->checkPaymentStatus($tXid, $referenceNo, $amt);

        //echo $iMid." | ".$tXid." | ".$referenceNo." | ".$amt." | ".$merchantToken." | ".$pushedToken." | ".$paymentStatus->status."<br/><br/>";        
        
        //echo "<pre>";
        //print_r($paymentStatus);
        //echo "</pre>";
        //exit;
        
        if($pushedToken == $merchantToken) {
            if (isset($paymentStatus->status) && $paymentStatus->status == '0'){
                $status = Configuration::get('PS_OS_PAYMENT');
            }else{
                $status = Configuration::get('PS_OS_ERROR');
            }

            //change status order
            $history    = new OrderHistory();
            $history->id_order = (int)$referenceNo;
            $history->changeIdOrderState((int)$status, (int)$referenceNo); // Failed
            $history->add();

            //send email payment success
            $templateName = "payment";
            $sendEmail = $this->nicepayPayConfEmail($referenceNo, $status, array(), $templateName);
        }
    }

    public function nicepayPayConfEmail($order_id, $id_order_state, $extra_vars = array(), $tplName){
        $order = new Order($order_id);
        $customer = new Customer($order->id_customer);
        if ($id_order_state != Configuration::get('PS_OS_ERROR') && $id_order_state != Configuration::get('PS_OS_CANCELED') && $order->id_customer) {
            
            $invoice = new Address($order->id_address_invoice);
            $delivery = new Address($order->id_address_delivery);
            $delivery_state = $delivery->id_state ? new State($delivery->id_state) : false;
            $invoice_state = $invoice->id_state ? new State($invoice->id_state) : false;
            $virtual_product = false;
            $data = array(
                '{firstname}' => $customer->firstname,
                '{lastname}' => $customer->lastname,
                '{email}' => $customer->email,
                '{order_name}' => $order->getUniqReference(),
                '{date}' => Tools::displayDate(date('Y-m-d H:i:s'), null, 1),
                '{payment}' => Tools::substr($order->payment, 0, 32)
            );            
            
            if(is_array($extra_vars)){
                $data = array_merge($data, $extra_vars);
            }
            
            $titleMail = "Status Pembayaran ".$order->getUniqReference();

            if (Validate::isEmail($customer->email)){
                Mail::Send(
                    (int)$order->id_lang,
                    $tplName,
                    Mail::l($titleMail, (int)$order->id_lang),
                    $data,
                    $customer->email,
                    $customer->firstname.' '.$customer->lastname,
                    null,
                    null,
                    null,
                    null, 
                    _PS_MAIL_DIR_,
                    false,
                    (int)$order->id_shop
                );
            }
        }
    }
}
?>