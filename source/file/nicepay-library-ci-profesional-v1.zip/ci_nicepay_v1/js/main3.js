function CCIcon(type) {
    var classIdentifier = 'fa-credit-card';
	if (type) {
		classIdentifier = 'fa-cc-' + type;
	}
	if (!$('.icarddata').hasClass(classIdentifier)) {
		var classes = '';
		for (var i in $.payform.cards) {
			classes += 'fa-cc-' + $.payform.cards[i].type + ' ';
        }
        $('.icarddata').removeClass(classes + 'fa-credit-card');
        $('.icarddata').addClass(classIdentifier);
    }
}


$(document).ready(function() {
    $('#CCexpired').mask("99 / 99",{placeholder:"MM / YY"});
    $('#CCcvv').mask("9999",{placeholder:""});
    $('#ccnum').bind("paste", function (e){e.preventDefault();}).payform('formatCardNumber');


    $('#ccnum').focusout( function() {
        var ccvalidate = $.payform.validateCardNumber($('#ccnum').val());
        var cctype = $.payform.parseCardType($('#ccnum').val());
        //CCvalid(ccvalidate);
        CCIcon(cctype);
        if(!ccvalidate) {
            $('.card-wrapper').text("Invalid Card Number");
            $(this).css('box-shadow','0px 0px 3px 1px rgba(255, 0, 0, 1)');
        }
        else {
            $('.card-wrapper').text("");
            $(this).css('box-shadow','none');
        } 
    });
    //
    $('#CCexpired').focusout( function() {
        var ccexp = $.payform.parseCardExpiry($('#CCexpired').val());
        var validate = $.payform.validateCardExpiry(ccexp);
        if (!validate) {
            $('.card-wrapper').text("Invalid Expiring Card");
            $(this).css('box-shadow','0px 0px 3px 1px rgba(255, 0, 0, 1)');
        }
        else {
            $('.card-wrapper').text("");
            $(this).css('box-shadow','none');
        }
    });

    $('.iconbtn2').click(function() {
        var tempID = $(this).attr('id');
        
        if(tempID == "show") {
            $('.overflow5').show("show");
            $('.iconbtn#hide').hide("fade",function() {
                $('.iconbtn#show').show("fade");
            });
            $(this).attr('id','hide');
            //$('.iconbtn#hide').show();
        }
        else {
            $('.overflow5').hide("hide");
            $('.iconbtn#show').hide("fade",function() {
                $('.iconbtn#hide').show("fade");
            });
            $(this).attr('id','show');
        }
    });

    $('.slidehide').click(function() {
        $('.overflow5').hide("hide");
            $('.iconbtn#show').hide("fade",function() {
                $('.iconbtn#hide').show("fade");
            });
            $('.iconbtn2').attr('id','show');
    });

    $(".ButtonRight").on('click', function(e) {
        e.preventDefault()
        var divname = this.name;
        var defaultX = "";
        var defaultY = "";
        if (divname == "TabMenu") {
            defaultX = "right";
            defaultY = "left";
        }
        else {
            defaultX = "left";
            defaultY = "right";
        }
        $(this).parents().eq(2).hide("blind", { direction: defaultX }, 400,function() {
            $("#"+divname).show("blind", { direction: defaultY }, 400);
        });
        //$(this).parents().eq(2).toggle("slide", { direction: defaultX },400);
        //$("#"+divname).toggle("slide", { direction: defaultY },400);
    });
});