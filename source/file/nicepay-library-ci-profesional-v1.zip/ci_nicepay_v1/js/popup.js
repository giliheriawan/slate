$(window).on('load',function(){
    $('#PopupPayment').modal('show');
});


$(document).ready(function(){
    $(".destroy").click(function(){
        //window.parent.location.href="http://localhost/template/paymentmethod/thankyou.html";
        $('iframe', window.parent.document).remove();
        console.log('test');
    });
});
