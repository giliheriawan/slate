<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ExampleCancel extends CI_Controller {

  private $apiUrl = 'https://www.nicepay.co.id/nicepay/api/onePassAllCancel.do';
  private $timeout_connect = 30;
  
  //private $no = 0;

  public function __construct(){
    parent::__construct();

  } 


  public function index()
  {
   
    $requestData = array();
    $requestData['tXid'] = $_POST['tXid'];
    $requestData['iMid'] = $_POST['iMid'];
    $requestData['merchantKey'] = $_POST['merchantKey'];
    $requestData['referenceNo'] = $_POST['referenceNo'];
    $requestData['payMethod'] = $_POST['payMethod'];
    $requestData['cancelType'] = $_POST['cancelType'];
    $requestData['cancelMsg'] = $_POST['cancelMsg'];
    $requestData['amt'] = $_POST['amt'];
    $requestData['description'] = 'Payment Of Ref No.' . $requestData['referenceNo'];
    $requestData['merchantToken'] = hash('sha256', $requestData['iMid'].$requestData['tXid'].$requestData['amt'].$requestData['merchantKey']);
    
    //$requestData['vacctValidDt'] =$tgl;
    //$requestData['vacctValidTm'] ='235959';
    //print_r($requestData); exit;

    $postData = '';
    foreach ($requestData as $key => $value) {
      $postData .= urlencode($key) . '='.urlencode($value).'&';
    }
    $postData = rtrim($postData, '&');

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    $curl_result = curl_exec($ch);
  
    $result = json_decode($curl_result);
    //print_r($result);exit;

    //Process Response Nicepay
    if(isset($result->resultCd) && $result->resultCd == "0000"){


      echo "<pre>";
      echo "tXid              : $result->tXid (Save to your database to check status) \n";
      // echo "callbackUrl       : $result->callbackUrl\n";
      // echo "description       : $result->description\n";
     
      echo "result code       : $result->resultCd\n";
      echo "amount            : $result->amount\n"; // YYMMDD
      echo "result message    : $result->resultMsg\n";
      echo "reference no      : $result->referenceNo\n";
      echo "payment time      : $result->transTm\n"; // HH24MISS
      echo "tXid              : $result->tXid \n";
      echo "Cancel tXid       : $result->canceltXid \n";
      echo "description       : $result->description \n";
      echo "transDt           : $result->transDt";
      echo "</pre>";
    }
    elseif (isset($result->resultCd)) {
      // API data not correct, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>";
      echo "result code       :".$result->resultCd."\n";
      echo "result message    :".$result->resultMsg."\n";
      echo "</pre>";
    }
    else {
      // Timeout, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>";
      echo "<pre>Connection Timeout. Please Try again.</pre>";
      echo "</pre>";
    }
  }

  private function generateReference()
  {
    $micro_date = microtime();
    $date_array = explode(" ",$micro_date);
    $date = date("YmdHis",$date_array[1]);
    $date_array[0] = preg_replace('/[^\p{L}\p{N}\s]/u', '', $date_array[0]);
    return "Ref".$date.$date_array[0].rand(100,999);
  }


}
