<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ExampleNotif extends CI_Controller {

  private $apiUrl ="https://www.nicepay.co.id/nicepay/api/onePassStatus.do";
  private $timeout_connect = 30;

  public function __construct(){
    parent::__construct();

  }


  public function index()
  {
    $requestData = array();
    $requestData['tXid'] = $_POST['tXid'];
    $requestData['iMid'] = 'BENSMART07';
    $requestData['referenceNo'] = $_POST['referenceNo'];
    $requestData['amt'] = $_POST['amt'];
    $requestData['merchantToken'] = hash('sha256', $requestData['iMid'].$requestData['referenceNo'].$requestData['amt'].'b1ez2W0tro8gE94P3tR+uwwY72g6gk5Y8bdnJVR0QwmnZv3eble1xvknGDik3wMC2HyjqrRwbCMvutaBemDCxA==');
   
    // print_r($requestData['merchantToken']); exit;
    $postData = '';
    foreach ($requestData as $key => $value) {
      $postData .= urlencode($key) . '='.urlencode($value).'&';
    }
    $postData = rtrim($postData, '&');

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    $curl_result = curl_exec($ch);
    $result = json_decode($curl_result);
    
    if(isset($result->resultCd) && $result->resultCd == "0000"){
      echo "<pre>";
      echo "tXid              : $result->tXid (Save to your database to check status) \n";
      // echo "callbackUrl       : $result->callbackUrl\n";
      // echo "description       : $result->description\n";
      echo "payment date      : $result->transDt\n"; // YYMMDD
      echo "payment time      : $result->transTm\n"; // HH24MISS
      echo "virtual account   : $result->vacctNo (For customer to transfer) \n";
      echo "result code       : $result->resultCd\n";
      echo "result message    : $result->resultMsg\n";
      echo "reference no      : $result->referenceNo\n";
      echo "payment method    : $result->payMethod";
      echo "</pre>";

    }
    elseif (isset($result->resultCd)) {
      // API data not correct, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>";
      echo "result code       :".$result->resultCd."\n";
      echo "result message    :".$result->resultMsg."\n";
      echo "</pre>";
    }
    else {
      // Timeout, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>";
      echo "<pre>Connection Timeout. Please Try again.</pre>";
      echo "</pre>";
    }




  }
}
