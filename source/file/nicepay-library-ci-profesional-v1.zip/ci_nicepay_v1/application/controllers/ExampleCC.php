<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ExampleCC extends CI_Controller {

  private $apiUrl = 'https://dev.nicepay.co.id/nicepay/api/orderRegist.do';
  private $timeout_connect = 30;

  public function __construct(){
    parent::__construct();
  }

  public function index()
  {

   
    $requestData = array();
    $requestData['iMid'] = $_POST['imid'];
    $requestData['payMethod'] = "01";
    $requestData['currency'] = "IDR";
    $requestData['merchantKey'] = $_POST['key'];
    $requestData['amt'] = $_POST['amt'];
    $requestData['instmntType'] = 1;
    $requestData['instmntMon'] = 1;
    $requestData['referenceNo'] = "Ini Invoice Merchant";
    $requestData['goodsNm'] = $requestData['referenceNo'];
    $requestData['billingNm'] = "John Doe";
    $requestData['billingPhone']  = "02112345678";
    $requestData['billingEmail'] = "john@example.com";
    $requestData['billingAddr'] = "Jl. Jend. Sudirman No. 28";
    $requestData['billingCity'] = "Jakarta Pusat";
    $requestData['billingState'] = "DKI Jakarta";
    $requestData['billingPostCd'] = "10210";
    $requestData['billingCountry'] = "Indonesia";
    $requestData['callBackUrl'] = "http://localhost/cha_nicepay_ci/CallbackCC";
    $requestData['dbProcessUrl'] = "http://localhost/Development/index.php/ExampleDbProcess";
    $requestData['description'] = "Payment Of Ref No." .$requestData['referenceNo'];
    $requestData['merchantToken'] = hash('sha256', $requestData['iMid'].$requestData['referenceNo'].$requestData['amt'].$requestData['merchantKey']);
    $requestData['userIP'] = $_SERVER['REMOTE_ADDR'];
    $requestData['cartData'] = "{}";  # Json Array Value

    $postData = '';
    foreach ($requestData as $key => $value) {
      $postData .= urlencode($key) . '='.urlencode($value).'&';
    }
    $postData = rtrim($postData, '&');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    $curl_result = curl_exec($ch);
    $result = json_decode(substr($curl_result,4));

    //print_r($requestData['iMid']); exit;
    //Process Response Nicepay
    if(isset($result->data->resultCd) && $result->data>resultCd == "0000"){
      header("Location: ".$result->data->requestURL."?tXid=".$result->data->tXid."&amt=".$requestData['amt']."&referenceNo=".$requestData['referenceNo']);
      //header("location:".site_url(CallbackCC)."?tXid=".$result->data->tXid."&amt=".$requestData['amt']."&referenceNo=".$requestData['referenceNo']);
    }
    elseif (isset($result->data->resultCd)) {
      // API data not correct, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>";
      echo "result code       :".$result->data->resultCd."\n";
      echo "result message    :".$result->data->resultMsg."\n";
      echo "</pre>";
    }
    else {
      // Timeout, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>Connection Timeout. Please Try again.</pre>";
    }
  }

  private function generateReference()
  {
    $micro_date = microtime();
    $date_array = explode(" ",$micro_date);
    $date = date("YmdHis",$date_array[1]);
    $date_array[0] = preg_replace('/[^\p{L}\p{N}\s]/u', '', $date_array[0]);
    return "Ref".$date.$date_array[0].rand(100,999);
  }
}
