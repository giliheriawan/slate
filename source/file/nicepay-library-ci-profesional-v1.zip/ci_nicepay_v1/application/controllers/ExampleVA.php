<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ExampleVA extends CI_Controller {

  private $apiUrl = 'https://www.nicepay.co.id/nicepay/api/onePass.do';
  private $timeout_connect = 30;
  
  //private $no = 0;

  public function __construct(){
    parent::__construct();

  }


  public function index()
  {
    //print_r($_POST); exit;
    //$no = $no+1;
    $tgl = date("Y-m-d H:i:s");
    $requestData = array();
    $requestData['iMid'] = $_POST['mid'];
    $requestData['payMethod'] = '02';
    $requestData['currency'] = 'IDR';
    $requestData['merchantKey'] = $_POST['key'];
    $requestData['amt'] = $_POST['amt'];
    $requestData['bankCd'] = $_POST['bankcd'];
    $requestData['referenceNo'] = 'invoice'.$tgl;
    $requestData['goodsNm'] = $requestData['referenceNo'];
    $requestData['billingNm'] = 'John Doe';
    $requestData['billingPhone'] = '02112345678';
    $requestData['billingEmail'] = 'john@example.com';
    $requestData['billingAddr'] = 'Jl. Jend. Sudirman No. 28';
    $requestData['billingCity'] = 'Jakarta Pusat';
    $requestData['billingState'] = 'DKI Jakarta';
    $requestData['billingPostCd'] = '10210';
    $requestData['billingCountry'] = 'Indonesia';
    $requestData['callbackUrl'] = 'http://localhost/Development/index.php/ExampleCallback';
    $requestData['dbProcessUrl'] = 'http://localhost/cha_nicepay_ci/ExampleNotif';
    $requestData['description'] = 'Payment Of Ref No.' . $requestData['referenceNo'];
    $requestData['merchantToken'] = hash('sha256', $requestData['iMid'].$requestData['referenceNo'].$requestData['amt'].$requestData['merchantKey']);
    $requestData[' userIP'] = $_SERVER['REMOTE_ADDR'];
    $requestData['cartData'] ='{}';
    // $requestData['vacctValidDt'] =$tgl; 
    // $requestData['vacctValidTm'] ='000000';   // test 
    //print_r($requestData['referenceNo']); exit;

    $postData = '';
    foreach ($requestData as $key => $value) {
      $postData .= urlencode($key) . '='.urlencode($value).'&';
    }
    $postData = rtrim($postData, '&');

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    $curl_result = curl_exec($ch);
   //  $this->nicepayva->iMid = $_POST['imid']; 
   //  $this->nicepayva->merchantKey = $_POST['key'];
   //  $this->nicepayva->amt = $_POST['amt'];
   //  $this->nicepayva->bankCd = $_POST['bankcd'];
   //  $this->nicepayva->referenceNo = $this->generateReference(); 
   //  $this->nicepayva->goodsNm = $this->nicepayva->referenceNo;
   //  $this->nicepayva->billingNm = "John Doe";
   //  $this->nicepayva->billingPhone = "02112345678";
   //  $this->nicepayva->billingEmail = "john@example.com";
   //  $this->nicepayva->billingAddr = "Jl. Jend. Sudirman No. 28";
   //  $this->nicepayva->billingCity = "Jakarta Pusat";
   //  $this->nicepayva->billingState = "DKI Jakarta";
   //  $this->nicepayva->billingPostCd = "10210";
   //  $this->nicepayva->billingCountry = "Indonesia";
   //  $this->nicepayva->callBackUrl = "http://localhost/Development/index.php/ExampleCallback";
   //  $this->nicepayva->dbProcessUrl = "http://localhost/Development/index.php/ExampleDbProcess";
   //  $this->nicepayva->description = "Payment Of Ref No." . $this->nicepayva->referenceNo;
   //  $this->nicepayva->merchantToken = hash('sha256', $this->nicepayva->iMid.$this->nicepayva->referenceNo.$this->nicepayva->amt.$this->nicepayva->merchantKey); 
   //  $this->nicepayva->userIP = $_SERVER['REMOTE_ADDR'];
   //  $this->nicepayva->cartData = "{}";  # Json Array Value
	  // $this->nicepayva->vacctValidDt =  '20180101'; //Expiry Date VA, set format (YYYYMMDD)
   //  $this->nicepayva->vacctValidTm = '235959'; //Expiry Time VA, set format (his)

   // // $this->nicepayva->apiRequest();
   //  $jsonresult = $this->apiRequest();
    $result = json_decode($curl_result);
    //print_r($result);exit;

    //Process Response Nicepay
    if(isset($result->resultCd) && $result->resultCd == "0000"){
      echo "<pre>";
      echo "tXid              : $result->tXid (Save to your database to check status) \n";
      echo "callbackUrl       : $result->callbackUrl\n";
      echo "description       : $result->description\n";
      echo "payment date      : $result->transDt\n"; // YYMMDD
      echo "payment time      : $result->transTm\n"; // HH24MISS
      echo "virtual account   : $result->bankVacctNo (For customer to transfer) \n";
      echo "result code       : $result->resultCd\n";
      echo "result message    : $result->resultMsg\n";
      echo "reference no      : $result->referenceNo\n";
      echo "payment method    : $result->payMethod";
      echo "</pre>";
    }
    elseif (isset($result->resultCd)) {
      // API data not correct, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>";
      echo "result code       :".$result->resultCd."\n";
      echo "result message    :".$result->resultMsg."\n";
      echo "</pre>";
    }
    else {
      // Timeout, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>";
      echo "<pre>Connection Timeout. Please Try again.</pre>";
      echo "</pre>";
    }
  }

  


}
