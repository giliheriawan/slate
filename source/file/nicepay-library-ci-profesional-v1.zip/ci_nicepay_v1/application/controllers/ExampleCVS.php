<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ExampleCVS extends CI_Controller {

  private $apiUrl = 'https://dev.nicepay.co.id/nicepay/api/onePass.do';
  private $timeout_connect = 30;
  
  //private $no = 0;

  public function __construct(){
    parent::__construct();

  }


  public function index()
  {
    //print_r($_POST); exit;
    //$no = $no+1;
    $tgl = date("Y-m-d H:i:s");
    $requestData = array();
    $requestData['iMid'] = $_POST['mid'];
    $requestData['payMethod'] = '03';
    $requestData['currency'] = 'IDR';
    $requestData['merchantKey'] = $_POST['key'];
    $requestData['amt'] = $_POST['amt'];
    $requestData['referenceNo'] = 'invoice'.$tgl;
    $requestData['goodsNm'] = $requestData['referenceNo'];
    $requestData['billingNm'] = 'John Doe';
    $requestData['billingPhone'] = '02112345678';
    $requestData['billingEmail'] = 'john@example.com';
    $requestData['billingState'] = 'DKI Jakarta';
    $requestData['billingPostCd'] = '10210';
    $requestData['billingCountry'] = 'Indonesia';
    $requestData['callbackUrl'] = 'http://localhost/Development/index.php/ExampleCallback';
    $requestData['dbProcessUrl'] = 'http://localhost/cha_nicepay_ci/ExampleNotif';
    $requestData['description'] = 'Payment Of Ref No.' . $requestData['referenceNo'];
    $requestData['merchantToken'] = hash('sha256', $requestData['iMid'].$requestData['referenceNo'].$requestData['amt'].$requestData['merchantKey']);
    $requestData['mitraCd'] = $_POST['mitraCd'];
    $requestData['cartData'] ='{}';
   
    // print_r($requestData); exit;

    $postData = '';
    foreach ($requestData as $key => $value) {
      $postData .= urlencode($key) . '='.urlencode($value).'&';
    }
    $postData = rtrim($postData, '&');

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    $curl_result = curl_exec($ch);
 
    $result = json_decode($curl_result);
    // print_r($result);exit;

    //Process Response Nicepay
    if(isset($result->resultCd) && $result->resultCd == "0000"){
      // print_r($result);exit;
      echo "<pre>";
      echo "tXid              : $result->tXid (Save to your database to check status) \n";
      echo "amount            : $result->amount\n";
      echo "description       : $result->description\n";
      echo "payment date      : $result->transDt\n"; // YYMMDD
      echo "payment time      : $result->transTm\n"; // HH24MISS
      echo "payment number    : $result->payNo (For customer to pay on convenience store) \n";
      echo "mitra code        : $result->mitraCd \n";
      echo "pay valid date    : $result->payValidDt\n";
      echo "pay valid time      : $result->payValidTm\n";
      echo "result code       : $result->resultCd\n";
      echo "result message    : $result->resultMsg\n";
      echo "reference no      : $result->referenceNo\n";
      echo "payment method    : $result->payMethod";
      echo "</pre>";
    }
    elseif (isset($result->resultCd)) {
      // API data not correct, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>";
      echo "result code       :".$result->resultCd."\n";
      echo "result message    :".$result->resultMsg."\n";
      echo "</pre>";
    }
    else {
      // Timeout, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>";
      echo "<pre>Connection Timeout. Please Try again.</pre>";
      echo "</pre>";
    }
  }

  


}
