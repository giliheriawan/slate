<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ExampleCallback extends CI_Controller {

  public function __construct(){
    parent::__construct();
  }

	public function index()
	{
    $this->nicepaychecker->iMid = "IONPAYTEST";
    $this->nicepaychecker->merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==";
    $this->nicepaychecker->amt = $_GET['amount'];
    $this->nicepaychecker->referenceNo = $_GET['referenceNo'];
    $this->nicepaychecker->merchantToken = $this->nicepaychecker->getMerchantToken();
    $this->nicepaychecker->tXid = $_GET['tXid'];

    $this->nicepaychecker->apiRequest();
    $jsonresult = $this->nicepaychecker->apiRequest();
    $result = json_decode($jsonresult);

    //Process Response Nicepay
    if(isset($result->resultCd) && $result->resultCd == '0000'){
      echo "<pre>";
      echo "tXid              : $result->tXid (Save to your database to check status) \n";
      echo "result code       : $result->resultCd\n";
      echo "result message    : $result->resultMsg\n";
      echo "reference no      : $result->referenceNo\n";
      echo "payment method    : $result->payMethod\n";
      echo "currency          : $result->currency\n";
      echo "amt               : $result->amt\n";
      echo "installment month : $result->instmntMon\n";
      echo "status            : $result->status\n";
      echo "</pre>";
    }
    elseif (isset($result->resultCd)) {
      // API data not correct, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>";
      echo "result code       :".$result->resultCd."\n";
      echo "result message    :".$result->resultMsg."\n";
      echo "</pre>";
    }
    else {
      echo "<pre>";
      echo "Timeout When Checking Payment Status";
      echo "</pre>";
    }
	}
}
