<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ExampleCTH extends CI_Controller {

  private $apiUrl = 'https://www.nicepay.co.id/nicepay/api/onePass.do';
  private $timeout_connect = 30;
  
  //private $no = 0;

  public function __construct(){
    parent::__construct();

  }


  public function index()
  {
   
$imid = 'IONPAYTEST';
 // $key = 'B43BlMMaEyv60cvO5cs9rDZb5hhomi/S0JnkYeyt9jdoAfRRx5y5K4V49CwvAIOSrSH9z1do1sz+samfSj5Ddw==';
$key = '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==';
 // $refno = $_POST['transid'];
 $refno = 'test'.rand(1000,9999);
 $amount = '100000';
 $token = hash('sha256',time().$imid.$refno.$amount.$key);

 // $url = "http://ptsv2.com/t/7ryyy-1530176234/post";
  $url = "https://dev.nicepay.co.id/nicepay/api/onePass.do";

  $curl_post_data = array(
  // "timeStamp" => "20180517170942",
  "iMid" => $imid,
  "payMethod" => "02",
  "currency" => "IDR",
  "amt" => $amount,
  "referenceNo" => $refno,
  "goodsNm" => "Test Smark Topup",
  "description" => "Payment for ref: ".$refno,
  "billingNm" => "Test Name",
  "billingPhone" => "1234567890",
  "billingEmail" => "dmh2907@gmail.com",
  "billingCity" => "Jakarta",
  "billingState" => "DKI Jakarta",
  "billingPostCd" => "15222",
  "billingCountry" => "Indonesia",
  "callBackUrl" => "http://www.smarkapi.com",
  "dbProcessUrl" => "http://127.0.0.1:8080/nicepay/test3/dbProcess.do",
  "description" => "Smark Topup",
  "merchantToken" => $token,
  "cartData" => "{}",
  "bankCd" => "BRIN",
  "userIP" => "127.0.0.1"
  );

  $curl_post_data = http_build_query($curl_post_data);
  // print_r($curl_post_data);exit;
  $curl = curl_init($url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_POST, true);
  curl_setopt($curl, CURLOPT_POSTFIELDS, $curl_post_data);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
  curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
  $curl_response = curl_exec($curl);

    //   $ch = curl_init();
    // curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
    // curl_setopt($ch, CURLOPT_HEADER, 0);
    // curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout_connect);
    // curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->timeout_connect);
    // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);


  echo $curl_response;
  curl_close($curl);
  echo "refno: ".$refno;

  }

  


}
