<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CI_NicepayCC{

  protected $CI;

  private $payMethod = '01';
  private $currency = 'IDR';
  private $apiUrl = 'https://www.nicepay.co.id/nicepay/api/orderRegist.do';
  private $timeout_connect = 30;
  private $timeout_read = 25;

  public $iMid = 'IONPAYTEST';
  public $merchantKey = '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==';
  public $amt;
  public $instmntType;
  public $instmntMon;
  public $referenceNo;
  public $goodsNm;
  public $billingNm;
  public $billingPhone;
  public $billingEmail;
  public $billingAddr;
  public $billingCity;
  public $billingState;
  public $billingPostCd;
  public $billingCountry;
  public $callBackUrl;
  public $dbProcessUrl;
  public $description;
  public $merchantToken;
  public $userIP;
  public $cartData;

  public $requestData = array();
  public $resultData = array();

  function __construct()
  {
      $this->ci =& get_instance();
  }

  public function getUserIP(){
    return $_SERVER['REMOTE_ADDR'];
  }

  public function getMerchantToken(){
    if(!isset($this->iMid)){
      die("Cannot set Merchant Token, please set param iMid using this->nicepaycc->iMid = iMid values");
    }
    elseif(!isset($this->referenceNo)){
      die("Cannot set Merchant Token, please set param referenceNo using this->nicepaycc->referenceNo = referenceNo values");
    }
    elseif(!isset($this->amt)){
      die("Cannot set Merchant Token, please set param amt using this->nicepaycc->amt = amt values");
    }
    elseif(!isset($this->merchantKey)){
      die("Cannot set Merchant Token, please set param merchantKey using this->nicepaycc->merchantKey = merchantKey values");
    }
    else {
      $merchantToken = hash('sha256', $this->iMid.$this->referenceNo.$this->amt.$this->merchantKey);
      return $merchantToken;
    }
  }

  private function set_param(){
    $this->requestData['iMid'] = $this->iMid;
    $this->requestData['payMethod'] = $this->payMethod;
    $this->requestData['currency'] = $this->currency;
    $this->requestData['amt'] = $this->amt;
    $this->requestData['instmntType'] = $this->instmntType;
    $this->requestData['instmntMon'] = $this->instmntMon;
    $this->requestData['referenceNo'] = $this->referenceNo;
    $this->requestData['goodsNm'] = $this->goodsNm;
    $this->requestData['billingNm'] = $this->billingNm;
    $this->requestData['billingPhone'] = $this->billingPhone;
    $this->requestData['billingEmail'] = $this->billingEmail;
    $this->requestData['billingAddr'] = $this->billingAddr;
    $this->requestData['billingCity'] = $this->billingCity;
    $this->requestData['billingState'] = $this->billingState;
    $this->requestData['billingPostCd'] = $this->billingPostCd;
    $this->requestData['billingCountry'] = $this->billingCountry;
    $this->requestData['callBackUrl'] = $this->callBackUrl;
    $this->requestData['dbProcessUrl'] = $this->dbProcessUrl;
    $this->requestData['description'] = $this->description;
    $this->requestData['merchantToken'] = $this->merchantToken;
    $this->requestData['userIP'] = $this->userIP;
    $this->requestData['cartData'] = $this->cartData;
    return $this->requestData;
  }

  private function checkParams($requestData){
    foreach ($requestData as $key => $value) {
      if(!isset($this->requestData[$key])){
        die("Undefined mandatory parameter '". $key ."', please set param using this->nicepaycc->". $key ." = ". $key ." values");
      }
    }
  }

  public function apiRequest(){
    $this->set_param();
    // $this->checkParams($this->requestData);
    $postData = '';
    foreach ($this->requestData as $key => $value) {
      $postData .= urlencode($key) . '='.urlencode($value).'&';
    }
    $postData = rtrim($postData, '&');

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->timeout_connect);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    $result = curl_exec($ch);
    return substr($result,4);
  }
}
?>
