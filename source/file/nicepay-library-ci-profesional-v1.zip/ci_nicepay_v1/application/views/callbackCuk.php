<!DOCTYPE html>
<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

<script type="text/javascript" src="/nicepay/js/bootstrap.js"></script>
<link rel="stylesheet" type="text/css" href="/nicepay/css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="/nicepay/css/bootstrap_backup.css" />
<link rel="stylesheet" type="text/css" href="/nicepay/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="/nicepay/css/form.css" />
<link rel="stylesheet" type="text/css" href="/nicepay/css/bootstrap-responsive.css" />
<link rel="stylesheet" type="text/css" href="/nicepay/css/basic.css" />

<script type="text/javascript" src="/nicepay/js/jquery.js"></script>
<script type="text/javascript" src="/nicepay/js/jquery.min.js"></script>
<script type="text/javascript" src="/nicepay/js/common.js"></script>


<script>"undefined"==typeof CODE_LIVE&&(!function(e){var t={nonSecure:"62004",secure:"62009"},c={nonSecure:"http://",secure:"https://"},r={nonSecure:"127.0.0.1",secure:"gapdebug.local.genuitec.com"},n="https:"===window.location.protocol?"secure":"nonSecure";script=e.createElement("script"),script.type="text/javascript",script.async=!0,script.src=c[n]+r[n]+":"+t[n]+"/codelive-assets/bundle.js",e.getElementsByTagName("head")[0].appendChild(script)}(document),CODE_LIVE=!0);</script></head>

<body  data-genuitec-lp-enabled="false" data-genuitec-file-id="wc1-50" data-genuitec-path="/pg_was/src/main/webapp/WEB-INF/views/layouts/basic_template.jsp">
	<html>
<head>
<script type = "text/javascript">
	function setAcsInfo(){
		document.tranMgr.action = $("#callbackUrl").val();
		document.tranMgr.submit();
	}

</script>
<script>"undefined"==typeof CODE_LIVE&&(!function(e){var t={nonSecure:"62004",secure:"62009"},c={nonSecure:"http://",secure:"https://"},r={nonSecure:"127.0.0.1",secure:"gapdebug.local.genuitec.com"},n="https:"===window.location.protocol?"secure":"nonSecure";script=e.createElement("script"),script.type="text/javascript",script.async=!0,script.src=c[n]+r[n]+":"+t[n]+"/codelive-assets/bundle.js",e.getElementsByTagName("head")[0].appendChild(script)}(document),CODE_LIVE=!0);</script></head>
<style>
body {
    min-width: 100%;
    height:auto;
min-height: 500px;
overflow: none;
border: none;
background: url("/nicepay/images/rotate.gif") no-repeat center;
}
</style>
<body onLoad="javascript:setAcsInfo();" data-genuitec-lp-enabled="false" data-genuitec-file-id="wc1-9" data-genuitec-path="/pg_was/src/main/webapp/WEB-INF/views/ionPay/payment/directReturn.jsp">
	<form name="tranMgr" method="post" action="http://localhost/cha_nicepay_CI_V2/ExampleCallback" data-genuitec-lp-enabled="false" data-genuitec-file-id="wc1-9" data-genuitec-path="/pg_was/src/main/webapp/WEB-INF/views/ionPay/payment/directReturn.jsp">
		<input type="hidden" id="callbackUrl"  value="http://localhost/cha_nicepay_CI_V2/ExampleCallback">
		<input type="hidden" name="resultCd"  value="9127">
		<input type="hidden" name="resultMsg" value="Transaction already exist. Please make new transaction.">
		<input type="hidden" name="tXid" value="">
		<input type="hidden" name="referenceNo" value="TESTTEST02">
		<input type="hidden" name="payMethod" value="01">
		<input type="hidden" name="amt" value="10000">
		<input type="hidden" name="transDt" value="20180124">
		<input type="hidden" name="transTm" value="172732">
		<input type="hidden" name="description" value="">
		<input type="hidden" name="authNo" value="">
		<input type="hidden" name="issuBankCd" value="">
		<input type="hidden" name="acquBankCd" value="">
		<input type="hidden" name="cardNo" value="123456******3456">
		<input type="hidden" name="receiptCode" value="">
		<input type="hidden" name="mitraCd" value="">
		<input type="hidden" name="recurringToken" value="">
		<input type="hidden" name="preauthToken" value="">
		
		<input type="hidden" name="currency" value="IDR">
		<input type="hidden" name="goodsNm" value="invoice897">
		<input type="hidden" name="billingNm" value="John Doe">
		<input type="hidden" name="ccTransType" value="">
		<input type="hidden" name="mRefNo" value="">
		
		<input type="hidden" name="instmntType" value="2">
		<input type="hidden" name="instmntMon" value="1">
		
		<input type="hidden" name="cardExpYymm" value="2006">
		
		<input type="hidden" name="issuBankNm" value="">
		<input type="hidden" name="acquBankNm" value="">
	</form>
</body>
</html>
</body>

</html>