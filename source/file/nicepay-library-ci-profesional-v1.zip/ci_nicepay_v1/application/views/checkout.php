<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">


    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo site_url();?>/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo site_url();?>/css/font-awesome.css">
    <link rel="stylesheet" href="<?php echo site_url();?>/css/main3.css">

    <title>Payment Method</title>
</head>

<body>
    <header class="header bg-nicepay">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand"><img src="<?php echo site_url();?>/img/nicepay.jpg" class="img-fluid ImgLogo"></a>
                <b>PAYMENT GATEWAYS</b>
            </nav>
        </div>
    </header>

    <div class="container content">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-xl-6 col-md-8 mob-pl-5 mob-pr-5">
               <!--  <div class="card OrderInfo">
                    <div class="card-header bg-nicepay text-white font-weight-bold" role="tab" id="headingOne">
                        <div class="row iconbtn2" id="hide">
                            <div class="col">
                                Orders Detail
                            </div>
                            <div class="col-auto">
                                <i class="iconbtn fa fa-chevron-right hide" aria-hidden="true" name="hidden" id="hide"></i>
                                <i class="iconbtn fa fa-chevron-down " aria-hidden="true" name="hidden" id="show"></i>
                            </div>
                        </div>
                    </div>
                    <!-- <div id="collapseOne" class="collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion"> -->
                       <!--  <div class="card-body mob-pl-5 mob-pr-5 overflow5">
                            <table class="table table-hover">
                                <tbody>
                                    <tr>
                                        <th scope="row" width="20%" class="product"><img src="./img/product.jpg" class="img-fluid"></th>
                                        <td width="40%">Bobo Magazine <strong>x 2</strong></td>
                                        <td width="40%" class="text-right">Rp. 2,000,000.00</td>
                                    </tr>
                                    <tr>
                                        <th scope="row" width="20%" class="product"><img src="./img/product.jpg" class="img-fluid"></th>
                                        <td width="40%">Bobo Magazine <strong>x 2</strong></td>
                                        <td width="40%" class="text-right">Rp. 2,000,000.00</td>
                                    </tr>
                                    <tr>
                                        <th scope="row" width="20%" class="product"><img src="./img/product.jpg" class="img-fluid"></th>
                                        <td width="40%">Bobo Magazine <strong>x 2</strong></td>
                                        <td width="40%" class="text-right">Rp. 6,000,000.00</td>
                                    </tr>
                                </tbody>
                            </table>
                            <button type="button" class="btn btn-sm slidehide">Hide</button>
                        </div>
                        <!-- </div> -->
                  <!--   <div class="card-footer">
                        <div class="row">
                            <div class="col text-left total">
                                Total
                            </div>
                            <div class="col-auto">
                                <div class="totalamt">Rp. 4,000,000.00</div>
                            </div>
                        </div>

                    </div>
                </div>  -->
                <div class="card Paymethod">
                    <div class="card-header bg-nicepay text-white font-weight-bold" role="tab" id="headingOne">
                        Payment Method API Version 1 Profesional
                    </div>
                    <div class="card-body">
                        <div class="box" style="">
                            <!-- BEGIN TAB MENU -->
                            <div class="row pt-3 pb-3 bg-white Abs" id="TabMenu">
                                <div class="col-12">
                                    <div class="list-group">
                                        <a class="list-group-item ButtonRight" id="CCButton" name="TabCC">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="material-icons fa-2x text-dark">credit_card</i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Credit Card (Full Payment)</div>
                                                    <div class="SubTitle">Pay with credit card</div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-right float-right text-dark" aria-hidden="true"></i>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item ButtonRight" id="CCButton" name="TabCCinst">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="material-icons fa-2x text-dark">credit_card</i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Credit Card (Installment)</div>
                                                    <div class="SubTitle">Pay with credit card</div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-right float-right text-dark" aria-hidden="true"></i>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item ButtonRight" id="CCButton" name="TabCCrecur">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="material-icons fa-2x text-dark">credit_card</i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Credit Card (Recurring)</div>
                                                    <div class="SubTitle">Pay with credit card</div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-right float-right text-dark" aria-hidden="true"></i>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item ButtonRight" id="CCButton" name="TabCCpreauth">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="material-icons fa-2x text-dark">credit_card</i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Credit Card (PreAuth)</div>
                                                    <div class="SubTitle">Pay with credit card</div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-right float-right text-dark" aria-hidden="true"></i>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item ButtonRight" id="CCButton" name="TabTransfer">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="material-icons fa-2x text-dark">phonelink</i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Virtual Account (Normal VA)</div>
                                                    <div class="SubTitle">Pay via bank transfer, Virtual Account</div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-right float-right text-dark" aria-hidden="true"></i>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item ButtonRight" id="CCButton" name="TabVAfixllose">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="material-icons fa-2x text-dark">phonelink</i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Virtual Account (Fix Close VA)</div>
                                                    <div class="SubTitle">Pay via bank transfer, Virtual Account</div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-right float-right text-dark" aria-hidden="true"></i>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item ButtonRight" id="CCButton" name="TabVAfixopen">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="material-icons fa-2x text-dark">phonelink</i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Virtual Account (Fix Open VA)</div>
                                                    <div class="SubTitle">Pay via bank transfer, Virtual Account</div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-right float-right text-dark" aria-hidden="true"></i>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item ButtonRight" id="CCButton" name="TabCsv">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="material-icons fa-2x text-dark">store_mall_directory</i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Convenience Store</div>
                                                    <div class="SubTitle">Pay via indomaret, alfamart, alfamidi, Lawson, Dan+Dan Store</div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-right float-right text-dark" aria-hidden="true"></i>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item ButtonRight" id="CCButton" name="TabClickpay">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="material-icons fa-2x text-dark">devices_other</i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Click-Pay</div>
                                                    <div class="SubTitle">Pay via CIMB clicks, BCA klikpay</div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-right float-right text-dark" aria-hidden="true"></i>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item ButtonRight" id="CCButton" name="TabEwallet">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="material-icons fa-2x text-dark">account_balance_wallet</i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">E-Wallet</div>
                                                    <div class="SubTitle">Pay via sakuku, mandiri</div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-right float-right text-dark" aria-hidden="true"></i>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <!-- END TAB MENU -->
                            <!-- BEGIN TAB CC -->
                            <div class="row pt-3 pb-3 bg-white Abs" id="TabCC" style="">
                                <div class="col-12">
                                    <div class="list-group">
                                        <a class="list-group-item ButtonRight" name="TabMenu">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-left float-left text-dark" aria-hidden="true"></i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Back</div>
                                                </div>

                                            </div>
                                        </a>
                                    </div>
                                   
                                    <form action="<?php echo site_url();?>ExampleCC" method="post" id="CC">
                                        <div class="row HeadTitle">
                                            <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="iMid" id="Emailaddr">
                                                </div>
                                            </div>
                                             <div class="col-12 mb-1">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-user fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" placeholder="payMethod" type="text" name="name" id="CCname">
                                                </div>
                                            </div>
                                            <div class="col-12 mb-1">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-user fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" placeholder="currency" type="text" name="name" id="CCname">
                                                </div>
                                            </div>
                                            <div class="col-12  mb-1">
                                                <div class="input-group cc">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text notify" id="basic-addon1"><i class="fa fa-credit-card fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="amt" id="ccnum" name="ccnum" type="text" maxlength="20">

                                                    <div class="input-group-prepend icon">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="icarddata fa fa-credit-card fa-fw fa-lg"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                              <div class="col-12  mb-1">
                                                <div class="input-group cc">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text notify" id="basic-addon1"><i class="fa fa-credit-card fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="instmntType" id="ccnum" name="ccnum" type="text" maxlength="20">

                                                    <div class="input-group-prepend icon">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="icarddata fa fa-credit-card fa-fw fa-lg"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                             <div class="col-12  mb-1">
                                                <div class="input-group cc">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text notify" id="basic-addon1"><i class="fa fa-credit-card fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="instmntMon" id="ccnum" name="ccnum" type="text" maxlength="20">

                                                    <div class="input-group-prepend icon">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="icarddata fa fa-credit-card fa-fw fa-lg"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                             <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="referenceNo" id="Emailaddr">
                                                </div>
                                            </div>
                                             <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="goodsNm" id="Emailaddr">
                                                </div>
                                            </div>
                                             <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="billingNm" id="Emailaddr">
                                                </div>
                                            </div>
                                             <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="billingPhone" id="Emailaddr">
                                                </div>
                                            </div>
                                             <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="billingEmail" id="Emailaddr">
                                                </div>
                                            </div>
                                             <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="billingCity" id="Emailaddr">
                                                </div>
                                            </div>
                                             <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="billingState" id="Emailaddr">
                                                </div>
                                            </div>
                                             <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="billingPostCd" id="Emailaddr">
                                                </div>
                                            </div>
                                             <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="billingCountry" id="Emailaddr">
                                                </div>
                                            </div>
                                              <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="callBackUrl" id="Emailaddr">
                                                </div>
                                            </div>
                                              <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="dbProcessUrl" id="Emailaddr">
                                                </div>
                                            </div>
                                              <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="description" id="Emailaddr">
                                                </div>
                                            </div>
                                              <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="merchantToken" id="Emailaddr">
                                                </div>
                                            </div>
                                              <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="userIP" id="Emailaddr">
                                                </div>
                                            </div>
                                              <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="cartData" id="Emailaddr">
                                                </div>
                                            </div>
                                             <div class="col-12 mb-1 mt-2">
                                                  <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="recurrOpt" id="Emailaddr">
                                                </div>
                                            </div>
                                            <!-- <div><small>type: <strong id="ccnum-type">invalid</strong></small></div> -->
                                           
                                        
                                            <div class="col-12  mt-1 mb-1">
                                                <div class="card-wrapper"></div>
                                            </div>
                                            <div class="col-12 mt-1 mb-3">
                                                <button type="submit" class="btn btn-nicepay btn-sm btn-block font-weight-bold" form="CC">PROCESS</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- END TAB CC -->
                            <!-- BEGIN TAB CC -->
                            <div class="row pt-3 pb-3 bg-white Abs" id="TabCCinst" style="">
                                <div class="col-12">
                                    <div class="list-group">
                                        <a class="list-group-item ButtonRight" name="TabMenu">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-left float-left text-dark" aria-hidden="true"></i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Back</div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <form action="" method="" id="">
                                        <div class="row HeadTitle">
                                            <div class="col-12 mb-1 mt-2">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="Billing Email" id="Emailaddr">
                                                </div>
                                            </div>
                                            <div class="col-12 mb-1">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1"><i class="fa fa-user fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" placeholder="Full name" type="text" name="name" id="CCname">
                                                </div>
                                            </div>
                                            <div class="col-12  mb-1">
                                                <div class="input-group cc">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text notify" id="basic-addon1"><i class="fa fa-credit-card fa-fw"></i></span>
                                                    </div>
                                                    <input class="form-control" type="text" placeholder="Card number" id="ccnum" name="ccnum" type="text" maxlength="20">

                                                    <div class="input-group-prepend icon">
                                                        <span class="input-group-text" id="basic-addon1">
                                                            <i class="icarddata fa fa-credit-card fa-fw fa-lg"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- <div><small>type: <strong id="ccnum-type">invalid</strong></small></div> -->
                                            <div class="col-12  mb-1">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text ccexp" id="basic-addon1"><i class="fa fa-credit-card fa-fw"></i></span>
                                                    </div>
                                                    <input type="text" class="form-control" placeholder="MM/YY" type="tel" name="expiry" id="CCexpired">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text cccvv" id="basic-addon1"><i class="fa fa-lock fa-fw"></i></span>
                                                    </div>
                                                    <input type="tel" class="form-control" placeholder="CVC" type="number" name="cvc" id="CCcvv" maxlength="4">
                                                </div>
                                            </div>
                                            <div class="col-12  mt-1 mb-1">
                                                <div class="card-wrapper"></div>
                                            </div>
                                            <div class="col-12 mt-1 mb-3">
                                                <button type="button" class="btn btn-nicepay btn-sm btn-block font-weight-bold">PROCESS</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- END TAB CC -->
                            <!-- BEGIN TAB TRANSFER -->
                            <div class="row pt-3 pb-3 bg-white Abs" id="TabTransfer" style="">
                                <div class="col-12">
                                    <div class="list-group">
                                        <a class="list-group-item ButtonRight" name="TabMenu">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-left float-left text-dark" aria-hidden="true"></i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Back</div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <!-- BEGIN -->
                                <div class="col-12 mb-1 mt-2">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                        </div>
                                        <input class="form-control" type="text" placeholder="Billing Email" id="Emailaddr2">
                                    </div>
                                </div>
                                <div class="col-12 mt-3 mb-3">
                                    <div class="list-group TransGroup">
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/mandiri2.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Bank Mandiri</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/bca.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Bank BCA</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/bni.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Bank BNI</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/maybank.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Bank Maybank</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/permata.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Bank Permata</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/cimb.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Bank CIMB</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/danamon.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Bank Danamon</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/hana2.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Bank KEB HANA</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/bri.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Bank BRI</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                                </div>
                                                <div class="col-3 xcol">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Others Bank</div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-12 mt-2 mb-1">
                                    <button type="button" class="btn btn-nicepay btn-sm btn-block font-weight-bold">PROCESS</button>
                                </div>
                            </div>
                            <!-- END TAB TRANSFER -->
                            <!-- BEGIN TAB CSV -->
                            <div class="row pt-3 pb-3 bg-white Abs" id="TabCsv" style="">
                                <div class="col-12">
                                    <div class="list-group">
                                        <a class="list-group-item ButtonRight" name="TabMenu">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-left float-left text-dark" aria-hidden="true"></i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Back</div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-12 mb-2 mt-2">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                        </div>
                                        <input class="form-control" type="text" placeholder="Billing Email" id="Emailaddr3">
                                    </div>
                                </div>
                                <div class="col-12 mb-1">
                                    <div class="list-group TransGroup">
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/csv-alfamart.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Alfamart</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1">
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/csv-alfamidi.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Alfamidi</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1">
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/csv-indomaret.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Indomaret</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1">
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/csv-lawson.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Lawson</div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-12 mb-3">
                                    <button type="button" class="btn btn-nicepay btn-sm btn-block font-weight-bold">PROCESS</button>
                                </div>
                            </div>
                            <!-- END TAB CSV -->
                            <!-- BEGIN TAB CLICKPAY -->
                            <div class="row pt-3 pb-3 bg-white Abs" id="TabClickpay" style="">
                                <div class="col-12">
                                    <div class="list-group">
                                        <a class="list-group-item ButtonRight" name="TabMenu">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-left float-left text-dark" aria-hidden="true"></i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Back</div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-12 mb-2 mt-2">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                        </div>
                                        <input class="form-control" type="text" placeholder="Billing Email" id="Emailaddr4">
                                    </div>
                                </div>
                                <div class="col-12 mb-3">
                                    <div class="list-group TransGroup">
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/clickpay-cimb.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">CIMB Clicks</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1">
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/csv-alfamidi.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Alfamidi</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1">
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/clickpay-bca.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">BCA KlikPay</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1">
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/clickpay-mandiri.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Mandiri clickpay</div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-12 mt-3 mb-3">
                                    <button type="button" class="btn btn-nicepay btn-sm btn-block font-weight-bold">PROCESS</button>
                                </div>
                            </div>
                            <!-- END TAB CLICKPAY -->
                            <!-- BEGIN TAB EWALLET -->
                            <div class="row pt-3 pb-3 bg-white Abs" id="TabEwallet" style="">
                                <div class="col-12">
                                    <div class="list-group">
                                        <a class="list-group-item ButtonRight" name="TabMenu">
                                            <div class="row">
                                                <div class="col-auto">
                                                    <i class="fa fa-chevron-left float-left text-dark" aria-hidden="true"></i>
                                                </div>
                                                <div class="col">
                                                    <div class="Title">Back</div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-12 mb-2 mt-2">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o fa-fw"></i></span>
                                        </div>
                                        <input class="form-control" type="text" placeholder="Billing Email" id="Emailaddr5">
                                    </div>
                                </div>
                                <div class="col-12 mb-1">
                                    <div class="list-group TransGroup">
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/ecash-sakuku.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Sakuku</div>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="list-group-item">
                                            <div class="row">
                                                <div class="col-auto xcol">
                                                    <input type="radio" name="exampleRadios" id="exampleRadios1" value="option1">
                                                </div>
                                                <div class="col-3 xcol">
                                                    <img src="./img/ecash-mandiri.png" class="TransferImg img-fluid">
                                                </div>
                                                <div class="col xcol">
                                                    <div class="Title">Mandiri e-cash</div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-12 mb-3">
                                    <button type="button" class="btn btn-nicepay btn-sm btn-block font-weight-bold">PROCESS</button>
                                </div>
                            </div>
                            <!-- END TAB EWALLET -->
                        </div>
                    </div>
                    <div class="card-footer text-muted">
                        <i class="fa fa-lock fa-lg" aria-hidden="true">&nbsp;</i>
                        <span>Nice Pay Secure Payment</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="row"></div>
        <div class="row"></div>
    </div>

   <!--  <footer class="container footer">
        <div class="row top">
            <div class="col tambah">
                <img src="./img/footer-visa.png" class="ImgFooter img-fluid">
                <img src="./img/footer-master.png" class="ImgFooter img-fluid">
                <img src="./img/footer-jcb.png" class="ImgFooter img-fluid">
                <img src="./img/footer-amex.png" class="ImgFooter img-fluid">
                <img src="./img/secure.png" class="ImgFooterSec img-fluid">
                <img src="./img/geotrust-secure.png" class="ImgFooterSec2 img-fluid">
                <a href="https://seal.controlcase.com/index.php?page=showCert&cId=2349888351" onclick="window.open(this.href, 'windowName', 'width=1000, height=700, left=24, top=24, scrollbars, resizable'); return false;">
                    <img src="./img/PCI_logo.gif" class="ImgFooterSec2 img-fluid">
                </a>
            </div>
        </div>

        <div class="row bottom">
            <div class="col">
                <div class="copyright float-right">
                    All Rights Reserved ©
                    <script>
                    new Date().getFullYear() > 2017 && document.write(new Date().getFullYear());
                </script> NICE Pay
            </div>
        </div>
    </div>
</footer> -->
<script src="./js/jquery-3.2.1.js"></script>
<script src="./js/jquery-ui.js"></script>
<script src="./js/popper.min.js"></script>
<script src="./js/bootstrap.js"></script>
<script src="./js/jquery.maskedinput.js"></script>
<script src="./js/jquery.payform.js"></script>
<script src="./js/main3.js"></script>
</body>

</html>