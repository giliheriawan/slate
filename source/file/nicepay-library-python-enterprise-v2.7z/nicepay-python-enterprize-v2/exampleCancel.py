import json

#Import Library (Mandatory)
from Lib import Nicepay

#setMandatoryParameter
Nicepay.set('timeStamp', '20180109181300')
Nicepay.set('tXid', 'IONPAYTEST02201801121146555531')
Nicepay.set('iMid', Nicepay.iMid)
Nicepay.set('payMethod', '02')
Nicepay.set('cancelType', '1')
Nicepay.set('amt', '10000')
Nicepay.set('merchantToken', Nicepay.merchantTokenCancel())
Nicepay.set('preauthToken', '')

resultData = Nicepay.niceCancel()
result = json.loads(resultData)

#Payment Response String Format
try:
    result['resultCd']
except NameError:
    print "Connection Timeout. Please Try Again!"
else:
    if result['resultCd'] == '0000':
        print("tXid : " + result['tXid'])
        print("referenceNo : " + result['referenceNo'])
        print("resultCd : " + result['resultCd'])
        print("resultMsg : " + result['resultMsg'])
        print("transDt : " + result['transDt'])
        print("transTm : " + result['transTm'])
        if result['description']:
            print("description : " + result['description'])
        print("amt : " + result['amt'])
    else:
        print("resultCd : " + result['resultCd'])
        print("resultMsg : " + result['resultMsg'])