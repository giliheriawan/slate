import json

#Import Library (Mandatory)
from Lib import Nicepay

#setMandatoryParameter
Nicepay.set('iMid', Nicepay.iMid)
Nicepay.set('vacctNo', '1146555531')
Nicepay.set('startDt', '20180101')
Nicepay.set('endDt', '20180111')
Nicepay.set('merchantToken', Nicepay.merchantTokenVacctInquiry())

resultData = Nicepay.niceVacctInquiry()
result = json.loads(resultData)

#Payment Response String Format
try:
    result['resultCd']
except NameError:
    print "Connection Timeout. Please Try Again!"
else:
    if result['resultCd'] == '0000':
        print("resultCd : " + result['resultCd'])
        print("resultMsg : " + result['resultMsg'])
        print("vacctNo : " + result['vacctNo'])
        print("depositInfo : " + json.dumps(result['depositInfo']))
    else:
        print("resultCd : " + result['resultCd'])
        print("resultMsg : " + result['resultMsg'])