import json

#Import Library (Mandatory)
from Lib import Nicepay

#setMandatoryParameter
Nicepay.set('timeStamp', '20180122143100')
Nicepay.set('iMid', Nicepay.iMid)
Nicepay.set('merchantToken', '52a5c5bd8020e809e3dd01b603f0b9ec89dc4c084d5392763b5bb2f690d074c7')
Nicepay.set('cardBin', '406810') #Card Number 6 digit

resultData = Nicepay.niceInstallmentInfo()
result = json.loads(resultData)

#Payment Response String Format
try:
    result['resultCd']
except NameError:
    print "Connection Timeout. Please Try Again!"
else:
    if result['resultCd'] == '0000':
        print("resultCd : " + result['resultCd'])
        print("resultMsg : " + result['resultMsg'])
        if result['cardBrend']:
            print("cardBrend : " + result['cardBrend'])
        if result['issuBankCd']:
            print("issuBankCd : " + result['issuBankCd'])
        print("instmntInfo : " + json.dumps(result['instmntInfo']))
    else:
        print("resultCd : " + result['resultCd'])
        print("resultMsg : " + result['resultMsg'])