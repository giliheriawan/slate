<?php
/*
 * ____________________________________________________________
 *
 * Copyright (C) 2016 NICE IT&T
 *
 *
 * This config file may used as it is, there is no warranty.
 *
 * @ description : PHP SSL Client module.
 * @ name        : NicepayLite.php
 * @ author      : NICEPAY I&T (tech@nicepay.co.kr)
 * @ date        :
 * @ modify      : 09.03.2016
 *
 * 09.03.2016 Update Log
 *
 * ____________________________________________________________
 */

// Please set the following
// define("NICEPAY_IMID_VA", "IONPAYTEST"); // Merchant ID
// define("NICEPAY_MERCHANT_KEY_VA", "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A=="); // API Key
// define("NICEPAY_CALLBACK_URL_VA", "http://localhost/nicepay-sdk/result.html"); // Merchant's result page URL
// define("NICEPAY_DBPROCESS_URL_VA", "http://httpresponder.com/nicepay"); // Merchant's notification handler URL

/* TIMEOUT - Define as needed (in seconds) */
define("NICEPAY_TIMEOUT_CONNECT_CC", 15);
define("NICEPAY_TIMEOUT_READ_CC", 25);

// Please do not change
define("NICEPAY_PROGRAM_CC", "NicepayLite");
define("NICEPAY_VERSION_CC", "1.11");
define("NICEPAY_BUILDDATE_CC", "20160309");
// define("NICEPAY_REQ_CC_URL_VA", "https://api.nicepay.co.id/nicepay/direct/v2/registration"); // Registration API URL
define("NICEPAY_REG_URL_CC", "https://api.nicepay.co.id/nicepay/direct/v2/registration"); // Registration API URL
// define("NICEPAY_CANCEL_VA_URL", "https://api.nicepay.co.id/nicepay/direct/v2/cancel"); // Credit Card (CC), Virtual Account (VA), Convience Store (CVS) API URL
define("NICEPAY_ORDER_STATUS_URL_CC", "https://api.nicepay.co.id/nicepay/direct/v2/inquiry"); // request to check status of transaction
define("NICEPAY_READ_TIMEOUT_ERR_CC",  "10200");

/* LOG LEVEL */
// define("NICEPAY_LOG_CRITICAL_VA", 1);
// define("NICEPAY_LOG_ERROR_VA", 2);
// define("NICEPAY_LOG_NOTICE_VA", 3);
// define("NICEPAY_LOG_INFO_VA", 5);
// define("NICEPAY_LOG_DEBUG_VA", 7);
?>