<?php

require_once(DIR_SYSTEM . 'library/nicepay/NicepayLib.php');

class ControllerExtensionPaymentNicepayCC extends Controller {
  public function index() {
    $data['button_confirm'] = $this->language->get('button_confirm');

    $this->load->model('checkout/order');

    $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

    $this->language->load('extension/payment/nicepay_cc');

    $data['action'] = $this->url->link('extension/payment/nicepay_cc/send');
    $data['url_web'] = $this->url;

    $data['ap_merchant'] = $this->config->get('payment_nicepay_cc_merchant');
    $data['ap_currency'] = $order_info['currency_code'];
    $data['ap_security'] = $this->config->get('payment_nicepay_cc_security');
    $data['ap_rate'] = $this->config->get('payment_nicepay_cc_rate');
    $data['ap_inv_payment'] = $this->config->get('payment_nicepay_cc_invoice');
    $data['ap_amount'] = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);
    $data['ap_purchasetype'] = 'Item';
    $data['ap_itemname'] = $this->config->get('config_name') . ' - #' . $this->session->data['order_id'];
    $data['ap_itemcode'] = $this->session->data['order_id'];

    if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/extension/payment/nicepay_cc')) {
      $this->template = $this->config->get('config_template') . '/template/extension/payment/nicepay_cc';
    } else {
      $this->template = 'default/template/extension/payment/nicepay_cc';
    }

    return $this->load->view('extension/payment/nicepay_cc', $data);
  }

  private function simpleXor($string, $password) {
    $data = array();

    for ($i = 0; $i < strlen($password); $i++) {
      $data[$i] = ord(substr($password, $i, 1));
    }

    $output = '';

    for ($i = 0; $i < strlen($string); $i++) {
      $output .= chr(ord(substr($string, $i, 1)) ^ ($data[$i % strlen($password)]));
    }

    return $output;
  }

  public function send() {
    $this->load->model('checkout/order');
    $data['errors'] = array();
    $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

    $transaction_details = array();
    $transaction_details['mallId'] = $this->config->get('payment_nicepay_cc_merchant');
    $transaction_details['invoiceNo'] = $this->config->get('payment_nicepay_cc_merchant') .$order_info['invoice_prefix'].$order_info['order_id'];
    $transaction_details['amount'] = (int)$order_info['total'];
    $transaction_details['currencyCode'] = 360;

    $products = $this->cart->getProducts();
    foreach ($products as $product) {
      if (($this->config->get('config_customer_price') && $this->customer->isLogged()) || ! $this->config->get('config_customer_price')) {
        $product['price'] = $this->tax->calculate(
          $product['price'], $product['tax_class_id'], $this->config->get('config_tax')
        );
      }

      $orderInfo[] = array(
        'img_url' => HTTPS_SERVER. "image/". $product['image'],
        'goods_name' => $product['name'],
        'goods_detail' => $product['model']." x".$product['quantity']." item",
        'goods_amt' => (int)($product['price'] * $product['quantity'])
      );
    }

    if ($this->cart->hasShipping()) {
      $shipping_info = $this->session->data['shipping_method'];
      if (($this->config->get('config_customer_price') && $this->customer->isLogged()) || ! $this->config->get('config_customer_price')) {
        $shipping_info['cost'] = $this->tax->calculate(
        $shipping_info['cost'],
        $shipping_info['tax_class_id'],
        $this->config->get('config_tax'));
      }

      $orderInfo[] = array(
        'img_url' => HTTPS_SERVER. "image/nicepay/png/delivery.png",
        'goods_name' => "SHIPPING",
        'goods_detail' => 1,
        'goods_amt' => $shipping_info['cost']
      );
    }

    if ($this->config->get('config_currency') != 'IDR') {
      if ($this->currency->has('IDR')) {
        foreach ($orderInfo as &$item) {
          $item['goods_amt'] = intval($this->currency->convert(
            $item['goods_amt'], $this->config->get('config_currency'), 'IDR')
          );
        }
        unset($item);

        $transaction_details['amount'] = intval($this->currency->convert(
          $transaction_details['amount'],
          $this->config->get('config_currency'),
          'IDR'
        ));
      } else if ($this->config->get('payment_nicepay_cc_rate') > 0) {
        foreach ($orderInfo as &$item) {
          $item['goods_amt'] = intval($item['goods_amt'] * $this->config->get('payment_nicepay_cc_rate'));
        }

        unset($item);

        $transaction_details['amount'] = intval($transaction_details['amount'] * $this->config->get('payment_nicepay_cc_rate'));
      } else {
        $data['errors'][] = 'Currency IDR tidak terinstall atau Nicepay currency conversion rate tidak valid. Silahkan check option kurs dollar.';
      }
    }

    $total_price = 0;
    foreach ($orderInfo as $item) {
      $total_price += $item['goods_amt'];
    }

    if ($total_price != $transaction_details['amount']) {
      $orderInfo[] = array(
        'img_url' => HTTPS_SERVER. "image/nicepay/png/coupon.png",
        'goods_name' => "COUPON",
        'goods_detail' => 1,
        'goods_amt' => $transaction_details['amount'] - $total_price
      );
    }

    $order_total = 0;
    foreach ($orderInfo as $item) {
      $order_total += $item['goods_amt'];
    }

    $cartData = array(
      "count" => count($orderInfo),
      "item" => $orderInfo
    );

    $order_id = $this->session->data['order_id'];

    $billingNm = $order_info['payment_firstname']." ".$order_info['payment_lastname'];
    $billingEmail = $order_info['email'];
    $billingPhone = $order_info['telephone'];
    $billingAddr = $order_info['payment_address_1'];
    $billingCountry = $order_info['payment_iso_code_2'];
    $billingState = $order_info['payment_zone'];
    $billingCity = $order_info['payment_city'];
    $billingPostCd = $order_info['payment_postcode'];

    $deliveryNm = ($order_info['shipping_firstname'] == null && $order_info['shipping_lastname'] == null) ? $billingNm : $order_info['shipping_firstname'] ." ". $order_info['shipping_lastname'];
    $deliveryAddr = ($order_info['shipping_address_1'] == null ) ? $billingAddr : $order_info['shipping_address_1'];
    $deliveryCity = ($order_info['shipping_city'] == null) ? $billingCity : $order_info['shipping_city'];
    $deliveryCountry = ($order_info['shipping_iso_code_2'] == null) ? $billingCountry : $order_info['shipping_iso_code_2'];
    $deliveryState = ($order_info['shipping_zone'] == null) ? $billingState : $order_info['shipping_zone'];
    $deliveryEmail = ($order_info['email'] == null) ? $billingEmail : $order_info['email'];
    $deliveryPhone = ($order_info['telephone'] == null) ? $billingPhone : $order_info['telephone'];
    $deliveryPostCd = ($order_info['shipping_postcode'] == null) ? $billingPostCd : $order_info['shipping_postcode'];

    // Prepare Parameters
    $nicepay = new NicepayLib();

    // Populate Mandatory parameters to send
    $nicepay->set('payMethod', '01');
    $nicepay->set('currency', 'IDR');
    $nicepay->set('cartData', json_encode($cartData));
    $nicepay->set('amt', $order_total); // Total gross amount //
    $nicepay->set('referenceNo', $order_info['order_id']);
    $nicepay->set('description', 'Payment of invoice No '. $order_info['invoice_prefix'].$order_info['order_id']); // Transaction description

    $nicepay->callBackUrl = HTTP_SERVER . 'catalog/controller/extension/payment/nicepay_cc_response.php';
    $nicepay->dbProcessUrl = HTTP_SERVER . 'catalog/controller/extension/payment/nicepay_cc_response.php';
    $nicepay->set('billingNm', $billingNm); // Customer name
    $nicepay->set('billingPhone', $billingPhone); // Customer phone number
    $nicepay->set('billingEmail', $billingEmail); //
    $nicepay->set('billingAddr', $billingAddr);
    $nicepay->set('billingCity', $billingCity);
    $nicepay->set('billingState', $billingState);
    $nicepay->set('billingPostCd', $billingPostCd);
    $nicepay->set('billingCountry', $billingCountry);

    $nicepay->set('deliveryNm', $deliveryNm); // Delivery name
    $nicepay->set('deliveryPhone', $deliveryPhone);
    $nicepay->set('deliveryEmail', $deliveryEmail);
    $nicepay->set('deliveryAddr', $deliveryAddr);
    $nicepay->set('deliveryCity', $deliveryCity);
    $nicepay->set('deliveryState', $deliveryState);
    $nicepay->set('deliveryPostCd', $deliveryPostCd);
    $nicepay->set('deliveryCountry', $deliveryCountry);

    // Send Data
    $response = $nicepay->chargeCard();

    $this->model_checkout_order->addOrderHistory($this->session->data['order_id'], $this->config->get('payment_nicepay_cc_order_status_id'), 'Payment was made using NicePay Credit Card. Order Invoice ID is '.$order_info['invoice_prefix'].$order_info['order_id'].'. Transaction ID is '.$response->tXid, false);

    // Response from NICEPAY
    if (isset($response->data->resultCd) && $response->data->resultCd == "0000") {

      $this->response->redirect($response->data->requestURL."?tXid=".$response->tXid);

      // please save tXid in your database
      // echo "<pre>";
      // echo "tXid              : $response->tXid\n";
      // echo "API Type          : $response->apiType\n";
      // echo "Request Date      : $response->requestDate\n";
      // echo "Response Date     : $response->requestDate\n";
      // echo "</pre>";
    } elseif(isset($response->data->resultCd)) {
      // API data not correct or error happened in bank system, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      // header("Location: "."http://example.com/checkout.php");
      echo "<pre>";
      echo "result code       : ".$response->data->resultCd."\n";
      echo "result message    : ".$response->data->resultMsg."\n";
      // echo "requestUrl        : ".$response->data->requestURL."\n";
      echo "</pre>";
    } else {
      // Timeout, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      // header("Location: "."http://example.com/checkout.php");
      echo "<pre>Connection Timeout. Please Try again.</pre>";
    }
  }

  public function success() {
    $data['tXid'] = $_REQUEST['tXid'];
    $data['referenceNo'] = $_REQUEST['referenceNo'];
    $data['amount'] = $_REQUEST['amount'];
    $data['description'] = $_REQUEST['description'];
    $data['cardNo'] = $_REQUEST['cardNo'];
    $data['transDt'] = $_REQUEST['transDt'];
    $this->cart->clear();
    $this->response->redirect($this->url->link('extension/checkout/nicepay_cc_success', $data , 'SSL'));
  }


  public function oneLine($string){
    return preg_replace(array('/\n/','/\n\r/','/\r\n/','/\r/','/\s+/','/\s\s*/'), '', $string);
  }

  public function notificationHandler(){

    $this->load->model('checkout/order');

    $nicepay = new NicepayLib();

    // Listen for parameters passed
    $pushParameters = array(
      'tXid',
      'referenceNo',
      'amt',
      'merchantToken'
    );

    $nicepay->extractNotification($pushParameters);

    $iMid               = $nicepay->iMid;
    $tXid               = $nicepay->getNotification('tXid');
    $referenceNo        = $nicepay->getNotification('referenceNo');
    $amt                = $nicepay->getNotification('amt');
    $pushedToken        = $nicepay->getNotification('merchantToken');

    $nicepay->set('tXid', $tXid);
    $nicepay->set('referenceNo', $referenceNo);
    $nicepay->set('amt', $amt);
    $nicepay->set('iMid',$iMid);

    $merchantToken = $nicepay->merchantTokenC();
    $nicepay->set('merchantToken', $merchantToken);
    // <RESQUEST to NICEPAY>
    $paymentStatus = $nicepay->checkPaymentStatus($tXid, $referenceNo, $amt);

    if($pushedToken == $merchantToken) {
      if (isset($paymentStatus->status) && $paymentStatus->status == '0'){
        echo "success : ".$paymentStatus->status;
        $this->model_checkout_order->addOrderHistory($referenceNo, $this->config->get('payment_nicepay_cc_order_success_status_id'), 'Payment successfully through Nicepay Credit Card. With Order ID is '. $referenceNo.'. Transaction ID is '.$paymentStatus->tXid, TRUE);
      }else{
        echo "Fail : ".$paymentStatus->status;
        $this->model_checkout_order->addOrderHistory($referenceNo,10,'Payment failed through Nicepay Credit Card. With Transaction ID '. $referenceNo,TRUE);
      }
    }
  }
}
