<?php
// Heading
$_['heading_title']		 = 'Nicepay Credit Card';

// Text
$_['text_extension']	 = 'Extensions';
$_['text_success']		 = 'Success: You have modified Nicepay Credit Card account details!';
$_['text_edit']          = 'Edit Nicepay Credit Card';
$_['text_nicepay_cc']	 = '<a onclick="window.open(\'http://ionpay.net\');"><img src="view/image/payment/nicepay_cc.png" alt="nicepay" title="NICEPay Payment Gateway" style="border: 1px solid #EEEEEE;" /><br /></a>';

// Entry
$_['entry_merchant']		 = 'Nicepay Merchant ID';
$_['entry_security']		 = 'Nicepay Merchant Key';
$_['entry_display']		 = 'Direct Checkout';
$_['entry_test']		 = 'Test Mode';
$_['entry_total']		 = 'Total';
$_['entry_order_status'] = 'Order Status';
$_['entry_order_success_status'] = 'Order Success Status';
$_['entry_geo_zone']	 = 'Geo Zone';
$_['entry_status']		 = 'Status';
$_['entry_sort_order']	 = 'Sort Order';
$_['entry_callback']	 = 'Callback URL';
$_['entry_rate']  = 'Kurs Dollar';
$_['entry_invoice']      = 'Order Prefix (Ex: INV-)';

// Help
$_['help_security']		 = 'The merchant key to confirm transactions with (must be the same as defined on the merchant account configuration page).';
$_['help_total']		 = 'The checkout total the order must reach before this payment method becomes active.';
$_['help_order_status']		 = 'Please Select Pending';
$_['help_order_success_status']		 = 'Please Select Proccessing';
$_['help_rate']		 = 'Please Fill with Numeric. (Default : 1)';

// Error
$_['error_permission']	 = 'Warning: You do not have permission to modify payment Nicepay Credit Card!';
$_['error_merchant']		 = 'Merchant ID Required!';
$_['error_security']		 = 'Merchant Key Required!';
