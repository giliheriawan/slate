import json
from nicepay import NICEPay

#Set MID & Merchant Key
NICEPay.iMid = "FIXOPEN001" #Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==" #Set Merchant Key

#Set Mandatory Value
NICEPay.customerId = "999969"
NICEPay.startDt = "20161101"
NICEPay.endDt = "20161130"
NICEPay.merchantToken = NICEPay.getMerchantTokenCustDeposit()

#Customer Id Deposit Request
resultCustDeposit = NICEPay.custDeposit()

#Customer Id Deposit Response
result = json.loads(resultCustDeposit)

#VA Deposit Response String Format
print("resultCd : " + result['resultCd'])
print("resultMsg : " + result['resultMsg'])
print("customerId : " + result['customerId'])
print result['depositCustomerIdInfo']