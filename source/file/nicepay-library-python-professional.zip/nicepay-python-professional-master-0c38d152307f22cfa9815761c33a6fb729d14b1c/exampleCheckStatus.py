import json

from nicepay import NICEPay

#Set Parameters For Check Status
NICEPay.iMid = "IONPAYTEST" #Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==" #Set Merchant Key
NICEPay.amt = "100"
NICEPay.referenceNo = "379072"
NICEPay.merchantToken = NICEPay.getMerchantToken()
NICEPay.tXid = "IONPAYTEST02201609161449136760"

#Check Status Request
resultCheckStatus = NICEPay.checkStatus()

#Check Status Response
result = json.loads(resultCheckStatus)

#Check Payment Response String Format
print("resultCd : " + result['resultCd'])
print("resultMsg : " + result['resultMsg'])
print("tXid : " + result['tXid'])
print("iMid : " + result['iMid'])
print("currency : " + result['currency'])
print("amount : " + result['amt'])
print("instmntMon : " + result['instmntMon'])
print("instmntType : " + result['instmntType'])
print("referenceNo : " + result['referenceNo'])
print("goodsNm : " + result['goodsNm'])
print("payMethod : " + result['payMethod'])
print("billingNm : " + result['billingNm'])
print("merchantToken : " + result['merchantToken'])
print("reqDt : " + result['reqDt'])
print("reqTm : " + result['reqTm'])
print("status : " + result['status'])
print("bankCd : " + result['bankCd'])
print("vacctValidDt : " + result['vacctValidDt'])
print("vacctValidTm : " + result['vacctValidTm'])
print("vacctNo : " + result['vacctNo'])

