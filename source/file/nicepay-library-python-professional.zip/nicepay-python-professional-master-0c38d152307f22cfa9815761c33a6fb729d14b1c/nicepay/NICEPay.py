import socket
import hashlib
import sys
import urlparse
import httplib
import urllib

# Declare Mandatory Parameters
global iMid
global merchantKey
global payMethod
global amt
global referenceNo
global goodsNm
global billingNm
global billingPhone
global billingEmail
global billingAddr
global billingCity
global billingState
global billingPostCd
global billingCountry
global callBackUrl
global dbProcessUrl
global description
global merchantToken
global userIP
global cartData
global instmntType
global instmntMon
global bankCd
global tXid
global cancelType
global vacctNo
global startDt
global endDt
global customerId

currency = "IDR"
timeout_connect = 30
timeout_read = 25
requestData = {}
resultData = {}

def getUserIp():
    return socket.gethostbyname(socket.gethostname())

def getMerchantToken():
    if not iMid:
        sys.exit("Cannot set Merchant Token, please set param iMid using NICEPay.iMid = iMid values")
    elif not referenceNo:
        sys.exit("Cannot set Merchant Token, please set param referenceNo using NICEPay.referenceNo = referenceNo values")
    elif not amt:
        sys.exit("Cannot set Merchant Token, please set param amt using NICEPay.amt = amt values")
    elif not merchantKey:
        sys.exit("Cannot set Merchant Token, please set param merchantKey using NICEPay.merchantKey = merchantKey values")
    else:
        mercToken = iMid + referenceNo + amt + merchantKey
        token = hashlib.sha256(mercToken.encode('ascii')).hexdigest()
        return token

def getMerchantTokenCancel():
    if not iMid:
        sys.exit("Cannot set Merchant Token, please set param iMid using NICEPay.iMid = iMid values")
    elif not tXid:
        sys.exit("Cannot set Merchant Token, please set param referenceNo using NICEPay.tXid = tXid values")
    elif not amt:
        sys.exit("Cannot set Merchant Token, please set param amt using NICEPay.amt = amt values")
    elif not merchantKey:
        sys.exit("Cannot set Merchant Token, please set param merchantKey using NICEPay.merchantKey = merchantKey values")
    else:
        mercToken = iMid + tXid + amt + merchantKey
        token = hashlib.sha256(mercToken.encode('ascii')).hexdigest()
        return token

def getMerchantTokenVaDeposit():
    if not iMid:
        sys.exit("Cannot set Merchant Token, please set param iMid using NICEPay.iMid = iMid values")
    elif not vacctNo:
        sys.exit("Cannot set Merchant Token, please set param vacctNo using NICEPay.vacctNo = vacctNo values")
    elif not startDt:
        sys.exit("Cannot set Merchant Token, please set param amt using NICEPay.startDt = startDt values")
    elif not merchantKey:
        sys.exit("Cannot set Merchant Token, please set param merchantKey using NICEPay.merchantKey = merchantKey values")
    else:
        mercToken = iMid + vacctNo + startDt + merchantKey
        token = hashlib.sha256(mercToken.encode('ascii')).hexdigest()
        return token

def getMerchantTokenCustDeposit():
    if not iMid:
        sys.exit("Cannot set Merchant Token, please set param iMid using NICEPay.iMid = iMid values")
    elif not customerId:
        sys.exit("Cannot set Merchant Token, please set param customerId using NICEPay.customerId = customerId values")
    elif not startDt:
        sys.exit("Cannot set Merchant Token, please set param amt using NICEPay.startDt = startDt values")
    elif not merchantKey:
        sys.exit("Cannot set Merchant Token, please set param merchantKey using NICEPay.merchantKey = merchantKey values")
    else:
        mercToken = iMid + customerId + startDt + merchantKey
        token = hashlib.sha256(mercToken.encode('ascii')).hexdigest()
        return token

def setParams():
    requestData['iMid'] = iMid
    requestData['payMethod'] = payMethod
    requestData['currency'] = currency
    requestData['amt'] = amt
    requestData['referenceNo'] = referenceNo
    requestData['goodsNm'] = goodsNm
    requestData['billingNm'] = billingNm
    requestData['billingPhone'] = billingPhone
    requestData['billingEmail'] = billingEmail
    requestData['billingAddr'] = billingAddr
    requestData['billingCity'] = billingCity
    requestData['billingState'] = billingState
    requestData['billingPostCd'] = billingPostCd
    requestData['billingCountry'] = billingCountry
    requestData['callBackUrl'] = callBackUrl
    requestData['dbProcessUrl'] = dbProcessUrl
    requestData['description'] = description
    requestData['merchantToken'] = merchantToken
    requestData['userIP'] = userIP
    requestData['cartData'] = cartData
    return requestData

def setParamsCheckStatus():
    requestData['iMid'] = iMid
    requestData['merchantToken'] = merchantToken
    requestData['tXid'] = tXid
    requestData['referenceNo'] = referenceNo
    requestData['amt'] = amt
    return requestData

def setParamsCancel():
    requestData['tXid'] = tXid
    requestData['payMethod'] = payMethod
    requestData['cancelType'] = cancelType
    requestData['merchantToken'] = merchantToken
    requestData['iMid'] = iMid
    requestData['amt'] = amt
    return requestData

def setParamsVaDeposit():
    requestData['iMid'] = iMid
    requestData['vacctNo'] = vacctNo
    requestData['startDt'] = startDt
    requestData['endDt'] = endDt
    requestData['merchantToken'] = merchantToken
    return requestData

def setParamsCustDeposit():
    requestData['iMid'] = iMid
    requestData['customerId'] = customerId
    requestData['startDt'] = startDt
    requestData['endDt'] = endDt
    requestData['merchantToken'] = merchantToken
    return requestData

def apiRequest():
    setParams()
    if payMethod == "01":
        requestData['instmntType'] = instmntType
        requestData['instmntMon'] = instmntMon
        apiUrl = "https://www.nicepay.co.id/nicepay/api/orderRegist.do"
    elif payMethod == "02":
        requestData['bankCd'] = bankCd
        apiUrl = "https://www.nicepay.co.id/nicepay/api/onePass.do"
    host = urlparse.urlparse(apiUrl)
    hostUrl = host.netloc
    hostPath = host.path
    params = urllib.urlencode(requestData)
    headers = {"Content-type": "application/x-www-form-urlencoded"}
    conn = httplib.HTTPSConnection(hostUrl,443,0,0,0,timeout_connect)
    conn.request("POST",hostPath,params,headers)
    readData = conn.getresponse(timeout_read)
    resultData = readData.read()
    return resultData

def checkStatus():
    setParamsCheckStatus()
    apiUrl = "https://www.nicepay.co.id/nicepay/api/onePassStatus.do"
    host = urlparse.urlparse(apiUrl)
    hostUrl = host.netloc
    hostPath = host.path
    params = urllib.urlencode(requestData)
    headers = {"Content-type": "application/x-www-form-urlencoded"}
    conn = httplib.HTTPSConnection(hostUrl,443,0,0,0,timeout_connect)
    conn.request("POST",hostPath,params,headers)
    readData = conn.getresponse(timeout_read)
    resultData = readData.read()
    return resultData

def cancel():
    setParamsCancel()
    apiUrl = "https://www.nicepay.co.id/nicepay/api/onePassAllCancel.do"
    host = urlparse.urlparse(apiUrl)
    hostUrl = host.netloc
    hostPath = host.path
    params = urllib.urlencode(requestData)
    headers = {"Content-type": "application/x-www-form-urlencoded"}
    conn = httplib.HTTPSConnection(hostUrl,443,0,0,0,timeout_connect)
    conn.request("POST",hostPath,params,headers)
    readData = conn.getresponse(timeout_read)
    resultData = readData.read()
    return resultData

def vaDeposit():
    setParamsVaDeposit()
    apiUrl = "https://www.nicepay.co.id/nicepay/api/vacctInquiry.do"
    host = urlparse.urlparse(apiUrl)
    hostUrl = host.netloc
    hostPath = host.path
    params = urllib.urlencode(requestData)
    headers = {"Content-type": "application/x-www-form-urlencoded"}
    conn = httplib.HTTPSConnection(hostUrl,443,0,0,0,timeout_connect)
    conn.request("POST",hostPath,params,headers)
    readData = conn.getresponse(timeout_read)
    resultData = readData.read()
    return resultData

def custDeposit():
    setParamsCustDeposit()
    apiUrl = "https://www.nicepay.co.id/nicepay/api/vacctCustomerIdInquiry.do"
    host = urlparse.urlparse(apiUrl)
    hostUrl = host.netloc
    hostPath = host.path
    params = urllib.urlencode(requestData)
    headers = {"Content-type": "application/x-www-form-urlencoded"}
    conn = httplib.HTTPSConnection(hostUrl,443,0,0,0,timeout_connect)
    conn.request("POST",hostPath,params,headers)
    readData = conn.getresponse(timeout_read)
    resultData = readData.read()
    return resultData