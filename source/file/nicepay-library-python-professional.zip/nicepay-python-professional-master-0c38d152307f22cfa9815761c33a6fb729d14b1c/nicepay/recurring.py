import socket
import hashlib
import sys
import urlparse
import httplib
import urllib

global iMid
global merchantKey
global amt
global instmntType
global instmntMon
global referenceNo
global goodsNm
global billingNm
global billingPhone
global billingEmail
global billingAddr
global billingCity
global billingState
global billingPostCd
global billingCountry
global callBackUrl
global dbProcessUrl
global description
global merchantToken
global userIP
global cartData
global recurringToken

payMethod = "01"
currency = "IDR"
apiUrl = "https://www.nicepay.co.id/nicepay/api/recurringTrans.do"
timeout_connect = 30
timeout_read = 25
requestData = {}
resultData = {}

def getUserIp():
    return socket.gethostbyname(socket.gethostname())

def getMerchantToken():
    if not iMid:
        sys.exit("Cannot set Merchant Token, please set param iMid using requestVA.iMid = iMid values")
    elif not referenceNo:
        sys.exit("Cannot set Merchant Token, please set param referenceNo using requestVA.referenceNo = referenceNo values")
    elif not amt:
        sys.exit("Cannot set Merchant Token, please set param amt using requestVA.amt = amt values")
    elif not merchantKey:
        sys.exit("Cannot set Merchant Token, please set param merchantKey using requestVA.merchantKey = merchantKey values")
    else:
        mercToken = iMid + referenceNo + amt + merchantKey
        token = hashlib.sha256(mercToken.encode('ascii')).hexdigest()
        return token

def setParams():
    requestData['iMid'] = iMid
    requestData['payMethod'] = payMethod
    requestData['currency'] = currency
    requestData['amt'] = amt
    requestData['instmntType'] = instmntType
    requestData['instmntMon'] = instmntMon
    requestData['referenceNo'] = referenceNo
    requestData['goodsNm'] = goodsNm
    requestData['billingNm'] = billingNm
    requestData['billingPhone'] = billingPhone
    requestData['billingEmail'] = billingEmail
    requestData['billingAddr'] = billingAddr
    requestData['billingCity'] = billingCity
    requestData['billingState'] = billingState
    requestData['billingPostCd'] = billingPostCd
    requestData['billingCountry'] = billingCountry
    requestData['callBackUrl'] = callBackUrl
    requestData['dbProcessUrl'] = dbProcessUrl
    requestData['description'] = description
    requestData['merchantToken'] = merchantToken
    requestData['userIP'] = userIP
    requestData['cartData'] = cartData
    requestData['recurringToken'] = recurringToken
    return requestData

def checkParams(param):
    for (i, name) in enumerate(param):
        if not requestData[name]:
            sys.exit("Undefined mandatory parameter '" + name + "', please set param using requestVA."+name+" = "+name+" values")

def apiRequest():
    setParams()
    checkParams(requestData)
    host = urlparse.urlparse(apiUrl)
    hostUrl = host.netloc
    hostPath = host.path
    params = urllib.urlencode(requestData)
    headers = {"Content-type": "application/x-www-form-urlencoded"}
    conn = httplib.HTTPSConnection(hostUrl,443,0,0,0,timeout_connect)
    conn.request("POST",hostPath,params,headers)
    readData = conn.getresponse(timeout_read)
    resultData = readData.read()
    return resultData