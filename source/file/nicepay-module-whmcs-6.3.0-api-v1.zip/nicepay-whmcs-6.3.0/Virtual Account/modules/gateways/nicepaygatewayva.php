<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function nicepaygatewayva_MetaData()
{
    return array(
        'DisplayName' => 'Nicepay VA',
        'APIVersion' => '1.1', // Use API Version 1.1
        'DisableLocalCredtCardInput' => true,
        'TokenisedStorage' => false,
    );
}

function nicepaygatewayva_config()
{
    return array(
        // the friendly display name for a payment gateway should be
        // defined here for backwards compatibility
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'Nicepay VA',
        ),
        // a text field type allows for single line text input
        'NICEPAY_IMID' => array(
            'FriendlyName' => 'Merchant ID',
            'Type' => 'text',
            'Default' => 'IONPAYTEST',
            'Description' => 'Enter your Merchant ID here',
        ),
        'NICEPAY_MERCHANT_KEY' => array(
            'FriendlyName' => 'Merchant Key',
            'Type' => 'text',
            'Default' => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            'Description' => 'Enter your Merchant Key here',
        ),
        'VACCT_VALID_DT'  => array(
            'FriendlyName' => 'Expired Date',
            'Type' => 'text',
            'Default' => '1',
            'Description' => 'Time for expired number VA (days)',
        ),
        'VACCT_VALID_TM'  => array(
            'FriendlyName' => 'Expired Time',
            'Type' => 'text',
            'Default' => '1',
            'Description' => 'Time for expired number VA (minutes)',
        ),
        'NICEPAY_TIMEOUT_CONNECT' => array(
            'FriendlyName' => 'Timeout Connect',
            'Type' => 'text',
            'Default' => 15,
        ),
        'NICEPAY_TIMEOUT_READ' => array(
            'FriendlyName' => 'Timeout Read',
            'Type' => 'text',
            'Default' => 25,
        ),
    );
}

function nicepaygatewayva_link($params)
{
    // System Parameters
    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $returnUrl = $params['returnurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];

    //Nicepay Parameters
    $payMethod = '02';
    $currency = 'IDR';
    $longamt = strlen($params['amount']);
    $amt = substr($params['amount'],0,$longamt-3);
    $referenceNo = $params['invoiceid'];
    $description = 'Payment of Invoice No '.$referenceNo;
    $iMid = $params['NICEPAY_IMID'];
    $merchantToken = hash('sha256',$iMid.$referenceNo.$amt.$params['NICEPAY_MERCHANT_KEY']);
    $dbProcessUrl = $systemUrl . '/modules/gateways/notification/' . $moduleName . '.php';
    $callBackUrl = $systemUrl . '/modules/gateways/callback/' . $moduleName . '.php';
    $date_now = date('Ymd');
    $vacctValidDt = date('Ymd',strtotime($date_now . ' +'.$params['VACCT_VALID_DT'].' days'));
    $time_now = date('His');
    $vacctValidTm = date('His',strtotime($time_now . ' +'.$params['VACCT_VALID_TM'].' minutes'));
    $instmntMon = 1;
    $instmntType = 0;
    $userIP = getUserIP2();
    $goodsNm = 'Payment of Invoice No '.$referenceNo;
    $notaxAmt = 0;
    $fee = 0;
    $vat = 0;
    $cartData = '{}';

    //Client Parameters
    $billingNm = $params['clientdetails']['firstname'].' '.$params['clientdetails']['lastname'];
    $billingPhone = $params['clientdetails']['phonenumber'];
    $billingEmail = $params['clientdetails']['email'];
    $billingAddr = $params['clientdetails']['address1'].' '.$params['clientdetails']['address2'];
    $billingCity = $params['clientdetails']['city'];
    $billingState = $params['clientdetails']['state'];
    $billingPostCd = $params['clientdetails']['postcode'];
    $billingCountry = $params['clientdetails']['country'];

    $deliveryNm = $params['clientdetails']['firstname'].' '.$params['clientdetails']['lastname'];
    $deliveryPhone = $params['clientdetails']['phonenumber'];
    $deliveryEmail = $params['clientdetails']['email'];
    $deliveryAddr = $params['clientdetails']['address1'].' '.$params['clientdetails']['address2'];
    $deliveryCity = $params['clientdetails']['city'];
    $deliveryState = $params['clientdetails']['state'];
    $deliveryPostCd = $params['clientdetails']['postcode'];
    $deliveryCountry = $params['clientdetails']['country'];

    $url = $systemUrl.'/banktransfer.php';

    $postfields = array();
    $postfields['payMethod'] = $payMethod;
    $postfields['currency'] = $currency;
    $postfields['amt'] = $amt;
    $postfields['referenceNo'] = $referenceNo;
    $postfields['description'] = $description;
    $postfields['billingNm'] = $billingNm;
    $postfields['billingPhone'] = $billingPhone;
    $postfields['billingEmail'] = $billingEmail;
    $postfields['billingAddr'] = $billingAddr;
    $postfields['billingCity'] = $billingCity;
    $postfields['billingState'] = $billingState;
    $postfields['billingPostCd'] = $billingPostCd;
    $postfields['billingCountry'] = $billingCountry;
    $postfields['deliveryNm'] = $deliveryNm;
    $postfields['deliveryPhone'] = $deliveryPhone;
    $postfields['deliveryEmail'] = $deliveryEmail;
    $postfields['deliveryAddr'] = $deliveryAddr;
    $postfields['deliveryCity'] = $deliveryCity;
    $postfields['deliveryState'] = $deliveryState;
    $postfields['deliveryPostCd'] = $deliveryPostCd;
    $postfields['deliveryCountry'] = $deliveryCountry;
    $postfields['vacctValidDt'] = $vacctValidDt;
    $postfields['vacctValidTm'] = $vacctValidTm;
    $postfields['iMid'] = $iMid;
    $postfields['merchantToken'] = $merchantToken;
    $postfields['dbProcessUrl'] = $dbProcessUrl;
    $postfields['callBackUrl'] = $callBackUrl;
    $postfields['instmntMon'] = $instmntMon;
    $postfields['instmntType'] = $instmntType;
    $postfields['userIP'] = $userIP;
    $postfields['goodsNm'] = $goodsNm;
    $postfields['fee'] = $fee;
    $postfields['vat'] = $vat;
    $postfields['notaxAmt'] = $notaxAmt;
    $postfields['cartData'] = $cartData;

    $htmlOutput = '<form method="post" action="' . $url . '">';
    foreach ($postfields as $k => $v) {
        $htmlOutput .= '<input type="hidden" name="' . $k . '" value="' . $v . '" />';
    }
    $htmlOutput .= '<input type="submit" value="' . $langPayNow . '" />';
    $htmlOutput .= '</form>';
    return $htmlOutput;
}

function getUserIP2() {
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    return $ip;
}



function nicepaygatewayva_refund($params)
{
    // Gateway Configuration Parameters
    $accountId = $params['accountID'];
    $secretKey = $params['secretKey'];
    $testMode = $params['testMode'];
    $dropdownField = $params['dropdownField'];
    $radioField = $params['radioField'];
    $textareaField = $params['textareaField'];
    // Transaction Parameters
    $transactionIdToRefund = $params['transid'];
    $refundAmount = $params['amount'];
    $currencyCode = $params['currency'];
    // Client Parameters
    $firstname = $params['clientdetails']['firstname'];
    $lastname = $params['clientdetails']['lastname'];
    $email = $params['clientdetails']['email'];
    $address1 = $params['clientdetails']['address1'];
    $address2 = $params['clientdetails']['address2'];
    $city = $params['clientdetails']['city'];
    $state = $params['clientdetails']['state'];
    $postcode = $params['clientdetails']['postcode'];
    $country = $params['clientdetails']['country'];
    $phone = $params['clientdetails']['phonenumber'];
    // System Parameters
    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];
    // perform API call to initiate refund and interpret result
    return array(
        // 'success' if successful, otherwise 'declined', 'error' for failure
        'status' => 'success',
        // Data to be recorded in the gateway log - can be a string or array
        'rawdata' => $responseData,
        // Unique Transaction ID for the refund transaction
        'transid' => $refundTransactionId,
        // Optional fee amount for the fee value refunded
        'fees' => $feeAmount,
    );
}
/**
 * Cancel subscription.
 *
 * If the payment gateway creates subscriptions and stores the subscription
 * ID in tblhosting.subscriptionid, this function is called upon cancellation
 * or request by an admin user.
 *
 * @param array $params Payment Gateway Module Parameters
 *
 * @see http://docs.whmcs.com/Payment_Gateway_Module_Parameters
 *
 * @return array Transaction response status
 */
function nicepaygatewayva_cancelSubscription($params)
{
    // Gateway Configuration Parameters
    $accountId = $params['accountID'];
    $secretKey = $params['secretKey'];
    $testMode = $params['testMode'];
    $dropdownField = $params['dropdownField'];
    $radioField = $params['radioField'];
    $textareaField = $params['textareaField'];
    // Subscription Parameters
    $subscriptionIdToCancel = $params['subscriptionID'];
    // System Parameters
    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];
    // perform API call to cancel subscription and interpret result
    return array(
        // 'success' if successful, any other value for failure
        'status' => 'success',
        // Data to be recorded in the gateway log - can be a string or array
        'rawdata' => $responseData,
    );
}
