<?php

use WHMCS\Database\Capsule;

define("CLIENTAREA", true);
//define("FORCESSL", true); // Uncomment to force the page to use https://

require("init.php");
require_once __DIR__ . '/includes/gatewayfunctions.php';

$gatewayParams = getGatewayVariables('nicepaygatewayva');

$va = new WHMCS_ClientArea();

$va->setPageTitle("Detail Virtual Account untuk Pembayaran Pesanan Anda");

$va->addToBreadCrumb('index.php', Lang::trans('globalsystemname'));
$va->addToBreadCrumb('processva.php', 'Virtual Account');

class NicepayRequestor {
    public $sock = 0;
    public $apiUrl;
    public $port = 443;
    public $status;
    public $headers = "";
    public $body = "";
    public $request;
    public $errorcode;
    public $errormsg;
    public $log;
    public $timeout;

    public function openSocket($apiUrl,$nicepay_timeout_connect) {
        $host = parse_url($apiUrl, PHP_URL_HOST);
        $tryCount = 0;
        if (! $this->sock = @fsockopen ("ssl://".$host, $this->port, $errno, $errstr, $nicepay_timeout_connect )) {
            while ($tryCount < 5) {
                if ($this->sock = @fsockopen("ssl://".$host, $this->port, $errno, $errstr, $nicepay_timeout_connect )) {
                  print_r($this->sock); exit;
                    return true;
                }
                sleep(2);
                $tryCount++;
            }
            $this->errorcode = $errno;
            switch ($errno) {
                case - 3 :
                    $this->errormsg = 'Socket creation failed (-3)';
                case - 4 :
                    $this->errormsg = 'DNS lookup failure (-4)';
                case - 5 :
                    $this->errormsg = 'Connection refused or timed out (-5)';
                default :
                    $this->errormsg = 'Connection failed (' . $errno . ')';
                    $this->errormsg .= ' ' . $errstr;
            }
            return false;
        }
        return true;
    }

    public function apiRequest($data,$apiUrl,$nicepay_timeout_read) {
        $host = parse_url($apiUrl, PHP_URL_HOST);
        $uri = parse_url($apiUrl, PHP_URL_PATH);
        $this->headers = "";
        $this->body = "";
        $postdata = $this->buildQueryString ($data);

        /* Write */
        $request = "POST " . $uri . " HTTP/1.0\r\n";
        $request .= "Connection: close\r\n";
        $request .= "Host: " . $host . "\r\n";
        $request .= "Content-type: application/x-www-form-urlencoded\r\n";
        $request .= "Content-length: " . strlen ( $postdata ) . "\r\n";
        $request .= "Accept: */*\r\n";
        $request .= "\r\n";
        $request .= $postdata . "\r\n";
        $request .= "\r\n";
        if($this->sock) {
            fwrite ( $this->sock, $request );

            /* Read */
            stream_set_blocking ($this->sock, FALSE);

            $atStart = true;
            $IsHeader = true;
            $timeout = false;
            $start_time = time ();
            while ( ! feof ($this->sock ) && ! $timeout) {
                $line = fgets ($this->sock, 4096);
                $diff = time () - $start_time;
                if ($diff >= $nicepay_timeout_read) {
                    $timeout = true;
                }
                if ($IsHeader) {
                    if ($line == "") // for stream_set_blocking
                    {
                        continue;
                    }
                    if (substr ($line, 0, 2) == "\r\n") // end of header
                    {
                        $IsHeader = false;
                        continue;
                    }
                    $this->headers .= $line;
                    if ($atStart) {
                        $atStart = false;
                        if (! preg_match ( '/HTTP\/(\\d\\.\\d)\\s*(\\d+)\\s*(.*)/', $line, $m )) {
                            $this->errormsg = "Status code line invalid: " . htmlentities ( $line );
                            fclose ( $this->sock );
                            return false;
                        }
                        $http_version = $m [1];
                        $this->status = $m [2];
                        $status_string = $m [3];
                        continue;
                    }
                } else {
                    $this->body .= $line;
                }
            }
            fclose ( $this->sock );

            if ($timeout) {
                $this->errorcode = "10200";
                $this->errormsg = "Socket Timeout(" . $diff . "SEC)";
                return false;
            }

            if(!$this->parseResult($this->body)) {
                $this->body =   substr($this->body, 4);
                return $this->parseResult($this->body);
            }
            return $this->parseResult($this->body);
        } else {
            return false;
        }
    }

    public function buildQueryString($data) {
        $querystring = '';
        if (is_array ($data)) {
            foreach ($data as $key => $val) {
                if (is_array ($val)) {
                    foreach ($val as $val2) {
                        if ($key != "key")
                            $querystring .= urlencode ($key) . '=' . urlencode ( $val2 ) . '&';
                    }
                    } else {
                    if ($key != "key")
                        $querystring .= urlencode ($key) . '=' . urlencode ($val) . '&';
                    }
            }
        $querystring = substr ($querystring, 0, - 1);
        } else {
            $querystring = $data;
        }
            return $querystring;
    }

    public function netCancel() {
        return true;
    }

    public function getStatus() {
        return $this->status;
    }

    public function getBody() {
        return $this->body;
    }

    public function getHeaders() {
        return $this->headers;
    }

    public function getErrorMsg() {
        return $this->errormsg;
    }

    public function getErrorCode() {
        return $this->errorcode;
    }

    public function parseResult($result) {
        return json_decode($result);
    }
}

//SET DATA POST
$postfields = array (
  'payMethod' => $_POST['payMethod'],
  'currency' => $_POST['currency'],
  'amt' => $_POST['amt'],
  'referenceNo' => $_POST['referenceNo'],
  'description' => $_POST['description'],
  'bankCd' => $_POST['bankCd'],
  'billingNm' => $_POST['billingNm'],
  'billingPhone' => $_POST['billingPhone'],
  'billingEmail' => $_POST['billingEmail'],
  'billingAddr' => $_POST['billingAddr'],
  'billingCity' => $_POST['billingCity'],
  'billingState' => $_POST['billingState'],
  'billingPostCd' => $_POST['billingPostCd'],
  'billingCountry' => $_POST['billingCountry'],
  'deliveryNm' => $_POST['deliveryNm'],
  'deliveryPhone' => $_POST['deliveryPhone'],
  'deliveryEmail' => $_POST['deliveryEmail'],
  'deliveryAddr' => $_POST['deliveryAddr'],
  'deliveryCity' => $_POST['deliveryCity'],
  'deliveryState' => $_POST['deliveryState'],
  'deliveryPostCd' => $_POST['deliveryPostCd'],
  'deliveryCountry' => $_POST['deliveryCountry'],
  'vacctValidDt' => $_POST['vacctValidDt'],
  'vacctValidTm' => $_POST['vacctValidTm'],
  'iMid' => $_POST['iMid'],
  'merchantToken' => $_POST['merchantToken'],
  'dbProcessUrl' => $_POST['dbProcessUrl'],
  'callBackUrl' => $_POST['callBackUrl'],
  'instmntMon' => $_POST['instmntMon'],
  'instmntType' => $_POST['instmntType'],
  'userIP' => $_POST['userIP'],
  'goodsNm' => $_POST['goodsNm'],
  'vat' => $_POST['vat'],
  'fee' => $_POST['fee'],
  'notaxAmt' => $_POST['notaxAmt'],
  'cartData' => $_POST['cartData'],
);

$apiUrl = "https://www.nicepay.co.id/nicepay/api/onePass.do";
$niceReq = new NicepayRequestor;
$niceReq->openSocket($apiUrl,$gatewayParams['NICEPAY_TIMEOUT_CONNECT']);
$resultData = $niceReq->apiRequest($postfields,$apiUrl,$gatewayParams['NICEPAY_TIMEOUT_READ']);

//Response from NICEPAY
if(isset($resultData->resultCd) && $resultData->resultCd == "0000"){

  if($postfields['bankCd'] == "CENA"){
    $bankCode = "BCA";
  }elseif ($postfields['bankCd'] == "BNIN") {
    $bankCode = "BNI";
  }elseif ($postfields['bankCd'] == "BMRI") {
    $bankCode = "MANDIRI";
  }elseif ($postfields['bankCd'] == "HNBN") {
    $bankCode = "KEB Hana Bank";
  }elseif ($postfields['bankCd'] == "BBBA") {
    $bankCode = "PERMATA";
  }elseif ($postfields['bankCd'] == "IBBK") {
    $bankCode = "BII Maybank";
  }elseif ($postfields['bankCd'] == "BRIN") {
    $bankCode = "BRI";
  }elseif ($postfields['bankCd'] == "BNIA") {
    $bankCode = "CIMB";
  }elseif ($postfields['bankCd'] == "BDIN") {
    $bankCode = "DANAMON";
  }else {
    $bankCode = "Unknown";
  }

  $va->initPage();

  $va->assign('resultCd', $resultData->resultCd);
  $va->assign('amount', $resultData->amount);
  $va->assign('referenceNo', $resultData->referenceNo);
  $va->assign('transTm', $postfields['vacctValidTm']);
  $va->assign('payMethod', $resultData->payMethod);
  $va->assign('tXid', $resultData->tXid);
  $va->assign('description', $resultData->description);
  $va->assign('callbackUrl', $resultData->callbackUrl);
  $va->assign('bankVacctNo', $resultData->bankVacctNo);
  $va->assign('transDt', $postfields['vacctValidDt']);
  $va->assign('resultMsg', $resultData->resultMsg);
  $va->assign('bankCode', $bankCode);
  $va->assign('bankCd', $postfields['bankCd']);

  $va->assign('variablename', $value);

    # Check login status
    if ($va->isLoggedIn()) {

      # User is logged in - put any code you like here

      # Here's an example to get the currently logged in clients first name

      $clientName = Capsule::table('tblclients')
          ->where('id', '=', $va->getUserID())->pluck('firstname');

      $va->assign('clientname', $clientName);

    } else {

      # User is not logged in

    }
  //Send Email Invoice Unpaid to Customer
  $command = "sendemail";
  $adminuser = "admin";
  $values["customtype"] = "general";
  $values["customsubject"] = "Invoice Payment of ".$gatewayParams['companyName'];
  $values["custommessage"] = "
                                 <table>
                                  <tr>
                                    <td colspan='3'>Thank You for Your Order</td>
                                  </tr>
                                  <tr>
                                    <td colspan='3'>Here the Information of your payment :</td>
                                  </tr>
                                  <tr>
                                    <td>Invoice No</td>
                                    <td>:</td>
                                    <td>".$resultData->referenceNo."</td>
                                  </tr>
                                  <tr>
                                    <td>Transaction ID</td>
                                    <td>:</td>
                                    <td>".$resultData->tXid."</td>
                                  </tr>
                                  <tr>
                                    <td>Amount</td>
                                    <td>:</td>
                                    <td>".$resultData->amount."</td>
                                  </tr>
                                  <tr>
                                    <td>Bank</td>
                                    <td>:</td>
                                    <td>".$bankCode."</td>
                                  </tr>
                                  <tr>
                                    <td>Virtual Account Number</td>
                                    <td>:</td>
                                    <td>".$resultData->bankVacctNo."</td>
                                  </tr>
                                  <tr>
                                    <td>Expired Date (Ymd)</td>
                                    <td>:</td>
                                    <td>".$postfields['vacctValidDt']."</td>
                                  </tr>
                                  <tr>
                                    <td>Expired Time (His)</td>
                                    <td>:</td>
                                    <td>".$postfields['vacctValidTm']."</td>
                                  </tr>
                                  </table></nowiki>";
  $values["id"]            = 1;
  $result = localAPI($command,$values,$adminuser);

  $va->setTemplate('nicepay_success');

  $va->output();

  //header("Location: ".$resultData->data->requestURL."?tXid=".$resultData->tXid);
}elseif (isset($resultData->resultCd)) {
  $va->initPage();

  $va->assign('resultCd', $resultData->resultCd);
  $va->assign('resultMsg', $resultData->resultMsg);

  $va->assign('variablename', $value);

    # Check login status
    if ($va->isLoggedIn()) {

      # User is logged in - put any code you like here

      # Here's an example to get the currently logged in clients first name

      $clientName = Capsule::table('tblclients')
          ->where('id', '=', $va->getUserID())->pluck('firstname');

      $va->assign('clientname', $clientName);

    } else {

      # User is not logged in

    }
  $va->setTemplate('nicepay_failed');

  $va->output();
}else {
  $va->initPage();

  $va->assign('variablename', $value);

  # Check login status
  if ($va->isLoggedIn()) {

    # User is logged in - put any code you like here

    # Here's an example to get the currently logged in clients first name

    $clientName = Capsule::table('tblclients')
        ->where('id', '=', $va->getUserID())->pluck('firstname');

    $va->assign('clientname', $clientName);

  } else {

    # User is not logged in

  }
  $va->setTemplate('nicepay_timeout');

  $va->output();
}
