<?php

use WHMCS\Database\Capsule;

define("CLIENTAREA", true);
//define("FORCESSL", true); // Uncomment to force the page to use https://

require("init.php");
require_once __DIR__ . '/includes/gatewayfunctions.php';

$gatewayParams = getGatewayVariables('nicepaygatewayva');

$ca = new WHMCS_ClientArea();

$ca->setPageTitle("Choose Your Bank Transfer");

$ca->addToBreadCrumb('index.php', Lang::trans('globalsystemname'));
$ca->addToBreadCrumb('banktransfer.php', 'Bank Transfer');

$ca->initPage();

$ca->assign('payMethod', $_POST['payMethod']);
$ca->assign('currency', $_POST['currency']);
$ca->assign('amt', $_POST['amt']);
$ca->assign('referenceNo', $_POST['referenceNo']);
$ca->assign('description', $_POST['description']);
$ca->assign('billingNm', $_POST['billingNm']);
$ca->assign('billingPhone', $_POST['billingPhone']);
$ca->assign('billingEmail', $_POST['billingEmail']);
$ca->assign('billingAddr', $_POST['billingAddr']);
$ca->assign('billingCity', $_POST['billingCity']);
$ca->assign('billingState', $_POST['billingState']);
$ca->assign('billingPostCd', $_POST['billingPostCd']);
$ca->assign('billingCountry', $_POST['billingCountry']);
$ca->assign('deliveryNm', $_POST['deliveryNm']);
$ca->assign('deliveryPhone', $_POST['deliveryPhone']);
$ca->assign('deliveryEmail', $_POST['deliveryEmail']);
$ca->assign('deliveryAddr', $_POST['deliveryAddr']);
$ca->assign('deliveryCity', $_POST['deliveryCity']);
$ca->assign('deliveryState', $_POST['deliveryState']);
$ca->assign('deliveryPostCd', $_POST['deliveryPostCd']);
$ca->assign('deliveryCountry', $_POST['deliveryCountry']);
$ca->assign('vacctValidDt', $_POST['vacctValidDt']);
$ca->assign('vacctValidTm', $_POST['vacctValidTm']);
$ca->assign('iMid', $_POST['iMid']);
$ca->assign('merchantToken', $_POST['merchantToken']);
$ca->assign('dbProcessUrl', $_POST['dbProcessUrl']);
$ca->assign('callBackUrl', $_POST['callBackUrl']);
$ca->assign('instmntMon', $_POST['instmntMon']);
$ca->assign('instmntType', $_POST['instmntType']);
$ca->assign('userIP', $_POST['userIP']);
$ca->assign('goodsNm', $_POST['goodsNm']);
$ca->assign('fee', $_POST['fee']);
$ca->assign('vat', $_POST['vat']);
$ca->assign('notaxAmt', $_POST['notaxAmt']);
$ca->assign('cartData', $_POST['cartData']);
$ca->assign('Url', $gatewayParams['systemurl'].'/processva.php');

# To assign variables to the template system use the following syntax.
# These can then be referenced using {$variablename} in the template.

$ca->assign('variablename', $value);

# Check login status
if ($ca->isLoggedIn()) {

  # User is logged in - put any code you like here

  # Here's an example to get the currently logged in clients first name

  $clientName = Capsule::table('tblclients')
      ->where('id', '=', $ca->getUserID())->pluck('firstname');

  $ca->assign('clientname', $clientName);

} else {

  # User is not logged in

}

# Define the template filename to be used without the .tpl extension

$ca->setTemplate('banktransfer');

$ca->output();
