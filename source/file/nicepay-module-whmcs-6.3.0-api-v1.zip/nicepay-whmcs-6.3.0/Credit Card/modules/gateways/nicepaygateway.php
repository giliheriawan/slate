<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function nicepaygateway_MetaData()
{
    return array(
        'DisplayName' => 'Nicepay Credit Card',
        'APIVersion' => '1.1', // Use API Version 1.1
        'DisableLocalCredtCardInput' => true,
        'TokenisedStorage' => false,
    );
}

function nicepaygateway_config()
{
    return array(
        // the friendly display name for a payment gateway should be
        // defined here for backwards compatibility
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'Nicepay Credit Card',
        ),
        // a text field type allows for single line text input
        'NICEPAY_IMID' => array(
            'FriendlyName' => 'Merchant ID',
            'Type' => 'text',
            'Default' => 'IONPAYTEST',
            'Description' => 'Enter your Merchant ID here',
        ),
        'NICEPAY_MERCHANT_KEY' => array(
            'FriendlyName' => 'Merchant Key',
            'Type' => 'text',
            'Default' => '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==',
            'Description' => 'Enter your Merchant Key here',
        ),
        'NICEPAY_TIMEOUT_CONNECT' => array(
            'FriendlyName' => 'Timeout Connect',
            'Type' => 'text',
            'Default' => 15,
        ),
        'NICEPAY_TIMEOUT_READ' => array(
            'FriendlyName' => 'Timeout Read',
            'Type' => 'text',
            'Default' => 25,
        ),
    );
}

class NicepayRequestor {
    public $sock = 0;
    public $apiUrl;
    public $port = 443;
    public $status;
    public $headers = "";
    public $body = "";
    public $request;
    public $errorcode;
    public $errormsg;
    public $log;
    public $timeout;

    public function openSocket($apiUrl,$nicepay_timeout_connect) {
        $host = parse_url($apiUrl, PHP_URL_HOST);
        $tryCount = 0;
        if (! $this->sock = @fsockopen ("ssl://".$host, $this->port, $errno, $errstr, $nicepay_timeout_connect )) {
            while ($tryCount < 20) {
                if ($this->sock = @fsockopen("ssl://".$host, $this->port, $errno, $errstr, $nicepay_timeout_connect )) {
                    return true;
                }
                sleep(2);
                $tryCount++;
            }
            $this->errorcode = $errno;
            switch ($errno) {
                case - 3 :
                    $this->errormsg = 'Socket creation failed (-3)';
                case - 4 :
                    $this->errormsg = 'DNS lookup failure (-4)';
                case - 5 :
                    $this->errormsg = 'Connection refused or timed out (-5)';
                default :
                    $this->errormsg = 'Connection failed (' . $errno . ')';
                    $this->errormsg .= ' ' . $errstr;
            }
            return false;
        }
        return true;
    }

    public function apiRequest($data,$apiUrl,$nicepay_timeout_read) {
        $host = parse_url($apiUrl, PHP_URL_HOST);
        $uri = parse_url($apiUrl, PHP_URL_PATH);
        $this->headers = "";
        $this->body = "";
        $postdata = $this->buildQueryString ($data);

        /* Write */
        $request = "POST " . $uri . " HTTP/1.0\r\n";
        $request .= "Connection: close\r\n";
        $request .= "Host: " . $host . "\r\n";
        $request .= "Content-type: application/x-www-form-urlencoded\r\n";
        $request .= "Content-length: " . strlen ( $postdata ) . "\r\n";
        $request .= "Accept: */*\r\n";
        $request .= "\r\n";
        $request .= $postdata . "\r\n";
        $request .= "\r\n";
        if($this->sock) {
            fwrite ( $this->sock, $request );

            /* Read */
            stream_set_blocking ($this->sock, FALSE);

            $atStart = true;
            $IsHeader = true;
            $timeout = false;
            $start_time = time ();
            while ( ! feof ($this->sock ) && ! $timeout) {
                $line = fgets ($this->sock, 4096);
                $diff = time () - $start_time;
                if ($diff >= $nicepay_timeout_read) {
                    $timeout = true;
                }
                if ($IsHeader) {
                    if ($line == "") // for stream_set_blocking
                    {
                        continue;
                    }
                    if (substr ($line, 0, 2) == "\r\n") // end of header
                    {
                        $IsHeader = false;
                        continue;
                    }
                    $this->headers .= $line;
                    if ($atStart) {
                        $atStart = false;
                        if (! preg_match ( '/HTTP\/(\\d\\.\\d)\\s*(\\d+)\\s*(.*)/', $line, $m )) {
                            $this->errormsg = "Status code line invalid: " . htmlentities ( $line );
                            fclose ( $this->sock );
                            return false;
                        }
                        $http_version = $m [1];
                        $this->status = $m [2];
                        $status_string = $m [3];
                        continue;
                    }
                } else {
                    $this->body .= $line;
                }
            }
            fclose ( $this->sock );

            if ($timeout) {
                $this->errorcode = "10200";
                $this->errormsg = "Socket Timeout(" . $diff . "SEC)";
                return false;
            }

            if(!$this->parseResult($this->body)) {
                $this->body =   substr($this->body, 4);
                return $this->parseResult($this->body);
            }
            return $this->parseResult($this->body);
        } else {
            return false;
        }
    }

    public function buildQueryString($data) {
        $querystring = '';
        if (is_array ($data)) {
            foreach ($data as $key => $val) {
                if (is_array ($val)) {
                    foreach ($val as $val2) {
                        if ($key != "key")
                            $querystring .= urlencode ($key) . '=' . urlencode ( $val2 ) . '&';
                    }
                    } else {
                    if ($key != "key")
                        $querystring .= urlencode ($key) . '=' . urlencode ($val) . '&';
                    }
            }
        $querystring = substr ($querystring, 0, - 1);
        } else {
            $querystring = $data;
        }
            return $querystring;
    }

    public function netCancel() {
        return true;
    }

    public function getStatus() {
        return $this->status;
    }

    public function getBody() {
        return $this->body;
    }

    public function getHeaders() {
        return $this->headers;
    }

    public function getErrorMsg() {
        return $this->errormsg;
    }

    public function getErrorCode() {
        return $this->errorcode;
    }

    public function parseResult($result) {
        return json_decode($result);
    }
}

function nicepaygateway_link($params)
{
    $systemUrl = $params['systemurl'];
    $moduleName = $params['paymentmethod'];
    $payMethod = '01';
    $currency = 'IDR';
    $longamt = strlen($params['amount']);
    $amt = substr($params['amount'],0,$longamt-3);
    $referenceNo = $params['invoiceid'];
    $description = 'Payment of Invoice No '.$referenceNo;
    $billingNm = $params['clientdetails']['firstname'].' '.$params['clientdetails']['lastname'];
    $billingPhone = $params['clientdetails']['phonenumber'];
    $billingEmail = $params['clientdetails']['email'];
    $billingAddr = $params['clientdetails']['address1'].' '.$params['clientdetails']['address2'];
    $billingCity = $params['clientdetails']['city'];
    $billingState = $params['clientdetails']['state'];
    $billingPostCd = $params['clientdetails']['postcode'];
    $billingCountry = $params['clientdetails']['country'];
    $deliveryNm = $params['clientdetails']['firstname'].' '.$params['clientdetails']['lastname'];
    $deliveryPhone = $params['clientdetails']['phonenumber'];
    $deliveryEmail = $params['clientdetails']['email'];
    $deliveryAddr = $params['clientdetails']['address1'].' '.$params['clientdetails']['address2'];
    $deliveryCity = $params['clientdetails']['city'];
    $deliveryState = $params['clientdetails']['state'];
    $deliveryPostCd = $params['clientdetails']['postcode'];
    $deliveryCountry = $params['clientdetails']['country'];
    $iMid = $params['NICEPAY_IMID'];
    $merchantToken = hash('sha256',$iMid.$referenceNo.$amt.$params['NICEPAY_MERCHANT_KEY']);
    $dbProcessUrl = $systemUrl . '/modules/gateways/notification/' . $moduleName . '.php';
    $callBackUrl = $systemUrl . '/modules/gateways/callback/' . $moduleName . '.php';
    $instmntMon = 1;
    $instmntType = 0;
    $userIP = getUserIP();
    $goodsNm = 'Payment of Invoice No '.$referenceNo;
    $notaxAmt = 0;
    $fee = 0;
    $vat = 0;
    $cartData = '{}';

    $postfields = array();
    $postfields['payMethod'] = $payMethod;
    $postfields['currency'] = $currency;
    $postfields['amt'] = $amt;
    $postfields['referenceNo'] = $referenceNo;
    $postfields['description'] = $description;
    $postfields['billingNm'] = $billingNm;
    $postfields['billingPhone'] = $billingPhone;
    $postfields['billingEmail'] = $billingEmail;
    $postfields['billingAddr'] = $billingAddr;
    $postfields['billingCity'] = $billingCity;
    $postfields['billingState'] = $billingState;
    $postfields['billingPostCd'] = $billingPostCd;
    $postfields['billingCountry'] = $billingCountry;
    $postfields['deliveryNm'] = $deliveryNm;
    $postfields['deliveryPhone'] = $deliveryPhone;
    $postfields['deliveryEmail'] = $deliveryEmail;
    $postfields['deliveryAddr'] = $deliveryAddr;
    $postfields['deliveryCity'] = $deliveryCity;
    $postfields['deliveryState'] = $deliveryState;
    $postfields['deliveryPostCd'] = $deliveryPostCd;
    $postfields['deliveryCountry'] = $deliveryCountry;
    $postfields['iMid'] = $iMid;
    $postfields['merchantToken'] = $merchantToken;
    $postfields['dbProcessUrl'] = $dbProcessUrl;
    $postfields['callBackUrl'] = $callBackUrl;
    $postfields['instmntMon'] = $instmntMon;
    $postfields['instmntType'] = $instmntType;
    $postfields['userIP'] = $userIP;
    $postfields['goodsNm'] = $goodsNm;
    $postfields['notaxAmt'] = $notaxAmt;
    $postfields['fee'] = $fee;
    $postfields['vat'] = $vat;
    $postfields['cartData'] = $cartData;

    $apiUrl = 'https://www.nicepay.co.id/nicepay/api/orderRegist.do';
    $niceReq = new NicepayRequestor;
    $niceReq->openSocket($apiUrl,$params['NICEPAY_TIMEOUT_CONNECT']);
    $resultData = $niceReq->apiRequest($postfields,$apiUrl,$params['NICEPAY_TIMEOUT_READ']);


    //Response from NICEPAY
    if(isset($resultData->data->resultCd) && $resultData->data->resultCd == "0000"){
      header('Location: '.$resultData->data->requestURL.'?tXid='.$resultData->tXid);
    }elseif (isset($resultData->resultCd)) {
      // API data not correct, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>";
      echo "result code       :".$resultData->resultCd."\n";
      echo "result message    :".$resultData->resultMsg."\n";
      echo "</pre>";
    }else {
      // Timeout, you can redirect back to checkout page or echo error message.
      // In this sample, we echo error message
      echo "<pre>Connection Timeout. Please Try again.</pre>";
    }
}

function getUserIP() {
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    return $ip;
}

function openSocket($apiURL,$port,$sock,$nicepay_timeout_connect) {
    $host = parse_url($apiURL, PHP_URL_HOST);
    $tryCount = 0;
    if (! $sock = @fsockopen ("ssl://".$host, $port, $errno, $errstr, $nicepay_timeout_connect )) {
        while ($tryCount < 20) {
            if ($sock = @fsockopen("ssl://".$host, $port, $errno, $errstr, $nicepay_timeout_connect )) {
                return true;
            }
            sleep(2);
            $tryCount++;
        }
        $errorcode = errorcode($errno);

        switch ($errno) {
            case - 3 :
                $errormsg = errormsg('Socket creation failed (-3)');
            case - 4 :
                $errormsg = errormsg('DNS lookup failure (-4)');
            case - 5 :
                $errormsg = errormsg('Connection refused or timed out (-5)');
            default :
                $errormsg = 'Connection failed (' . $errno . ')';
                $errormsg .= ' ' . $errstr;
                $errormsg = errormsg($errormsg);
        }
        return false;
    }
    $sock = sock($sock);
    return true;
}
