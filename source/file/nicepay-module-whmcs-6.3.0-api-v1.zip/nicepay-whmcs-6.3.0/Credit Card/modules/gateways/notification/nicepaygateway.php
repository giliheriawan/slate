<?php
// Require libraries needed for gateway module functions.
require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';
// Detect module name from filename.
$gatewayModuleName = basename(__FILE__, '.php');
// Fetch gateway configuration parameters.
$gatewayParams = getGatewayVariables($gatewayModuleName);
// Die if module is not active.
if (!$gatewayParams['type']) {
    die("Module Not Activated");
}
// Retrieve data returned in payment gateway callback
// Varies per payment gateway
$iMid = $gatewayParams['NICEPAY_IMID'];
$merchantKey = $gatewayParams['NICEPAY_MERCHANT_KEY'];
$tXid = $_REQUEST['tXid'];
$referenceNo = $_REQUEST['referenceNo'];
$amt = $_REQUEST['amt'];
$pushedToken = $_REQUEST['merchantToken'];
$matchAmount = $_REQUEST['matchCl'];

$nicepay_timeout_connect = $gatewayParams['NICEPAY_TIMEOUT_CONNECT'];
$nicepay_timeout_read = $gatewayParams['NICEPAY_TIMEOUT_READ'];

$merchantToken = hash('sha256', $iMid.$tXid.$amt.$merchantKey);

// //CHECKING PAYMENT STATUS
// //REQUEST TO NICEPAY
$resultPayment = checkPaymentStatus($tXid,$referenceNo,$amt,$iMid,$merchantKey,$nicepay_timeout_connect,$nicepay_timeout_read);

function checkPaymentStatus($tXid, $referenceNo, $amt, $iMid, $merchantKey, $nicepay_timeout_connect,$nicepay_timeout_read) {
    $merchantToken = hash('sha256', $iMid.$referenceNo.$amt.$merchantKey);

    //SET DATA FOR POST CHECKING STATUS
    $data = array(
      'iMid'          => $iMid,
      'merchantToken' => $merchantToken,
      'tXid'          => $tXid,
      'referenceNo'   => $referenceNo,
      'amt'           => $amt
    );

    // Send Request
    $url = "https://www.nicepay.co.id/nicepay/api/onePassStatus.do";
    $socket = sockedOpen($url,$nicepay_timeout_connect);
    $resultData = apiRequest($data,$url,$socket,$nicepay_timeout_read);
    return $resultData;
}

function sockedOpen($url,$nicepay_timeout_connect){
    $sock = 0;
    $errorcode = '';
    $errormsg = '';
    $host = parse_url($url, PHP_URL_HOST);
    $tryCount = 0;
    if (! $sock = @fsockopen ("ssl://".$host, '443', $errno, $errstr, $nicepay_timeout_connect )) {
        while ($tryCount < 5) {
            if ($sock = @fsockopen("ssl://".$host, '443', $errno, $errstr, $nicepay_timeout_connect )) {
                return $sock;
            }
            sleep(2);
            $tryCount++;
        }
        $errorcode = $errno;
        switch ($errno) {
            case - 3 :
                $errormsg = 'Socket creation failed (-3)';
            case - 4 :
                $errormsg = 'DNS lookup failure (-4)';
            case - 5 :
                $errormsg = 'Connection refused or timed out (-5)';
            default :
                $errormsg = 'Connection failed (' . $errno . ')';
                $errormsg .= ' ' . $errstr;
        }
        return $sock;
    }
    return $sock;
}

function apiRequest($data,$url,$sock,$nicepay_timeout_read) {
    $status = '';
    $host = parse_url($url, PHP_URL_HOST);
    $uri = parse_url($url, PHP_URL_PATH);
    $headers = "";
    $body = "";
    $postdata = buildQueryString ($data);

    /* Write */
    $request = "POST " . $uri . " HTTP/1.0\r\n";
    $request .= "Connection: close\r\n";
    $request .= "Host: " . $host . "\r\n";
    $request .= "Content-type: application/x-www-form-urlencoded\r\n";
    $request .= "Content-length: " . strlen ( $postdata ) . "\r\n";
    $request .= "Accept: */*\r\n";
    $request .= "\r\n";
    $request .= $postdata . "\r\n";
    $request .= "\r\n";
    if($sock) {
        fwrite ( $sock, $request );

        /* Read */
        stream_set_blocking ($sock, FALSE);

        $atStart = true;
        $IsHeader = true;
        $timeout = false;
        $start_time = time ();
        while ( ! feof ($sock ) && ! $timeout) {
            $line = fgets ($sock, 4096);
            $diff = time () - $start_time;
            if ($diff >= $nicepay_timeout_read) {
                $timeout = true;
            }
            if ($IsHeader) {
                if ($line == "") // for stream_set_blocking
                {
                    continue;
                }
                if (substr ($line, 0, 2) == "\r\n") // end of header
                {
                    $IsHeader = false;
                    continue;
                }
                $headers .= $line;
                if ($atStart) {
                    $atStart = false;
                    if (! preg_match ( '/HTTP\/(\\d\\.\\d)\\s*(\\d+)\\s*(.*)/', $line, $m )) {
                        $errormsg = "Status code line invalid: " . htmlentities ( $line );
                        fclose ( $sock );
                        return false;
                    }
                    $http_version = $m [1];
                    $status = $m [2];
                    $status_string = $m [3];
                    continue;
                }
            } else {
                $body .= $line;
            }
        }
        fclose ( $sock );

        if ($timeout) {
            $errorcode = "10200";
            $errormsg = "Socket Timeout(" . $diff . "SEC)";
            return false;
        }
        // return true
        if(!parseResult($body)) {
            $body =   substr($body, 4);
            return parseResult($body);
        }
        return parseResult($body);
    } else {
        return false;
    }
}

function buildQueryString($data) {
    $querystring = '';
    if (is_array ($data)) {
        foreach ($data as $key => $val) {
            if (is_array ($val)) {
                foreach ($val as $val2) {
                    if ($key != "key")
                        $querystring .= urlencode ($key) . '=' . urlencode ( $val2 ) . '&';
                }
                } else {
                if ($key != "key")
                    $querystring .= urlencode ($key) . '=' . urlencode ($val) . '&';
                }
        }
    $querystring = substr ($querystring, 0, - 1);
    } else {
        $querystring = $data;
    }
        return $querystring;
}

function parseResult($result) {
    return json_decode($result);
}


if($pushedToken == $merchantToken){
  if($resultPayment->status == '0'){
    $transactionStatus = 'Success';
    $success = true;
  }elseif ($resultPayment->status == '1') {
    $transactionStatus = 'Reversal/Void';
    $success = false;
  }elseif ($resultPayment->status == '2') {
    $transactionStatus = 'Refund';
    $success = false;
  }elseif ($resultPayment->status == '3') {
    $transactionStatus = 'Unpaid';
    $success = false;
  }elseif ($resultPayment->status == '4') {
    $transactionStatus = 'Expired/Canceled by Merchant before Paid';
    $success = false;
  }elseif ($resultPayment->status == '9') {
    $transactionStatus = 'Initialization or Unpaid';
    $success = false;
  }else {
    $transactionStatus = 'Unknown Status';
    $success = false;
  }
}else {
  $transactionStatus = 'Token Not Match';
  $success = false;
}

$invoiceId = checkCbInvoiceID($referenceNo, $gatewayParams['name']);
checkCbTransID($invoiceId);

logTransaction('Nicepay Credit Card', 'Log Notification:'.json_encode($_REQUEST), $transactionStatus);
if ($success){
  $command = "updateinvoice";
  $adminuser = "admin";
  $values["invoiceid"] = $invoiceId;
  $values["status"] = "Paid";
  $results = localAPI($command,$values,$adminuser);
}
else {
  $command = "updateinvoice";
  $adminuser = "admin";
  $values["invoiceid"] = $invoiceId;
  $values["status"] = "Cancelled";
  $results = localAPI($command,$values,$adminuser);
}
?>
