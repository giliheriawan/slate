Plugin Name: NICEPay Payment Gateway
Plugin URI: http://nicepay.co.id
Description: NICEPay Payment Gateway
Version: 1.3
Author: NICEPay <codeNinja>
Author URI: http://nicepay.co.id


Feature :
- Adding admin fee and credit card fee