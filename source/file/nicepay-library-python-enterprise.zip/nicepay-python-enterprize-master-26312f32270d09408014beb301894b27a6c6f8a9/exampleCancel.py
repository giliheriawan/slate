import json

from nicepay import NICEPay

#Set MID & Merchant Key
NICEPay.iMid = "IONPAYTEST" #Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==" #Set Merchant Key

#Set Mandatory Value
NICEPay.payMethod = "02"
NICEPay.amt = "1000"
NICEPay.tXid = "IONPAYTEST02201704051816030915"
NICEPay.cancelType = "1"
NICEPay.merchantToken = NICEPay.getMerchantTokenCancel()

#Cancel Request
resultCancel = NICEPay.cancel()

#Cancel Response
result = json.loads(resultCancel)

#Cancel Response String Format
print("resultCd : " + result['resultCd'])
print("resultMsg : " + result['resultMsg'])
print("tXid : " + result['tXid'])
print("referenceNo : " + result['referenceNo'])
print("transDt : " + result['transDt'])
print("transTm : " + result['transTm'])
print("description : " + result['description'])
print("amount : " + result['amount'])