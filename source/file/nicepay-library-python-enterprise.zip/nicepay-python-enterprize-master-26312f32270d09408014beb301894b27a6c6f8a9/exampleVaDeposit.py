import json
from nicepay import NICEPay

#Set MID & Merchant Key
NICEPay.iMid = "FIXOPEN001" #Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==" #Set Merchant Key

#Set Mandatory Value
NICEPay.vacctNo = "4477910000009887"
NICEPay.startDt = "20161101"
NICEPay.endDt = "20161130"
NICEPay.merchantToken = NICEPay.getMerchantTokenVaDeposit()

#VA Deposit Request
resultVaDeposit = NICEPay.vaDeposit()

#VA Deposit Response
result = json.loads(resultVaDeposit)

#VA Deposit Response String Format
print("resultCd : " + result['resultCd'])
print("resultMsg : " + result['resultMsg'])
print("vacctNo : " + result['vacctNo'])
print result['depositInfo']