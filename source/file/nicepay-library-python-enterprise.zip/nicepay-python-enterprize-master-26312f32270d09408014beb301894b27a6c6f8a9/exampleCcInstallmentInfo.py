import json

from nicepay import NICEPay

#Set Parameters For CC Installment Information
NICEPay.iMid = "IONPAYTEST" #Set Merchant ID
NICEPay.merchantKey = "33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A==" #Set Merchant Key
NICEPay.merchantToken = NICEPay.gerMerchantTokenCcInsInfo()

#Cc Installment Info Request
resultCcInsInfo = NICEPay.ccInsInfo()

#Check Status Response
result = json.loads(resultCcInsInfo)

#Check Payment Response String Format
print("resultCd : " + result['resultCd'])
print("resultMsg : " + result['resultMsg'])
print("instmntInfo : " + result['instmntInfo'])