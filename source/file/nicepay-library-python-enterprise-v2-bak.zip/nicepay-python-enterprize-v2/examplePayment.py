import json

#Import Library (Mandatory)
from Lib import Nicepay

#setMandatoryParameter (If do Payment Credit Card, please using web browser, because we will redirect to your callback url for OTP Page.)
Nicepay.set('timeStamp', '20180109181300')
Nicepay.set('tXid', 'IONPAYTEST02201802051512483907') #get tXid from register first
Nicepay.set('cardNo', '5409120028181901')
Nicepay.set('cardExpYymm', '2012') #format Yymm
Nicepay.set('cardCvv', '111')
Nicepay.set('recurringToken', '')
Nicepay.set('preauthToken', '')
Nicepay.set('clickPayNo', '')
Nicepay.set('dataField3', '')
Nicepay.set('clickPayToken', '')
Nicepay.set('merchantToken', '5a44213129be40320ef1a4b57095bfa61cd3ff0436bc442a9d82232e62203f37')
Nicepay.set('callBackUrl', '20180109181300')

resultData = Nicepay.nicePayment()
# result = json.loads(resultData)

print(resultData)