import socket
import hashlib
import sys
import urlparse
import httplib
import urllib
import json

global iMid
global merchantKey

iMid = 'IONPAYTEST'
merchantKey = '33F49GnCMS1mFYlGXisbUDzVf2ATWCl9k3R++d5hDd3Frmuos/XLx8XhXpe+LDYAbpGKZYSwtlyyLOtS/8aD7A=='
timeout_connect = 30
timeout_read = 25
requestData = {}
requestDataJson = {}
resultData = {}


def set(name,value):
    requestData[name] = value
    return requestData

def merchantToken():
    if not requestData['timeStamp']:
        sys.exit("Cannot set Merchant Token, please setting timeStamp")
    elif not requestData['referenceNo']:
        sys.exit("Cannot set Merchant Token, please setting referenceNo")
    elif not requestData['amt']:
        sys.exit("Cannot set Merchant Token, please setting amt")
    else:
        mercToken = requestData['timeStamp'] + iMid + requestData['referenceNo'] + requestData['amt'] + merchantKey
        token = hashlib.sha256(mercToken.encode('ascii')).hexdigest()
        return token

def merchantTokenCancel():
    if not requestData['timeStamp']:
        sys.exit("Cannot set Merchant Token, please setting timeStamp")
    elif not requestData['tXid']:
        sys.exit("Cannot set Merchant Token, please setting tXid")
    elif not requestData['amt']:
        sys.exit("Cannot set Merchant Token, please setting amt")
    else:
        mercToken = requestData['timeStamp'] + iMid + requestData['tXid'] + requestData['amt'] + merchantKey
        token = hashlib.sha256(mercToken.encode('ascii')).hexdigest()
        return token

def merchantTokenVacctInquiry():
    if not requestData['vacctNo']:
        sys.exit("Cannot set Merchant Token, please setting vacctNo")
    elif not requestData['startDt']:
        sys.exit("Cannot set Merchant Token, please setting startDt")
    else:
        mercToken = iMid + requestData['vacctNo'] + requestData['startDt'] + merchantKey
        token = hashlib.sha256(mercToken.encode('ascii')).hexdigest()
        return token

def merchantTokenCustomerIdInquiry():
    if not requestData['customerId']:
        sys.exit("Cannot set Merchant Token, please setting customerId")
    elif not requestData['startDt']:
        sys.exit("Cannot set Merchant Token, please setting startDt")
    else:
        mercToken = iMid + requestData['customerId'] + requestData['startDt'] + merchantKey
        token = hashlib.sha256(mercToken.encode('ascii')).hexdigest()
        return token

def userIp():
    return socket.gethostbyname(socket.gethostname())

def niceRegister():
    requestDataJson = json.dumps(requestData)
    apiUrl = "https://api.nicepay.co.id/nicepay/direct/v2/registration"
    resultData = sendDataJson(requestDataJson, apiUrl)
    return requestDataJson

def niceInquiry():
    requestDataJson = json.dumps(requestData)
    apiUrl = "https://api.nicepay.co.id/nicepay/direct/v2/inquiry"
    resultData = sendDataJson(requestDataJson,apiUrl)
    return resultData

def niceCancel():
    requestDataJson = json.dumps(requestData)
    apiUrl = "https://api.nicepay.co.id/nicepay/direct/v2/cancel"
    resultData = sendDataJson(requestDataJson, apiUrl)
    return resultData

def nicePayment():
    apiUrl = "https://api.nicepay.co.id/nicepay/direct/v2/payment"
    resultData = sendData(requestData, apiUrl)
    return resultData

def niceVacctInquiry():
    apiUrl = "https://api.nicepay.co.id/nicepay/api/vacctInquiry.do"
    resultData = sendData(requestData, apiUrl)
    return resultData

def niceCustomerIdInquiry():
    apiUrl = "https://api.nicepay.co.id/nicepay/api/vacctCustomerIdInquiry.do"
    resultData = sendData(requestData, apiUrl)
    return resultData

def niceInstallmentInfo():
    requestDataJson = json.dumps(requestData)
    apiUrl = "https://api.nicepay.co.id/nicepay/direct/v2/instInfoInquiry"
    resultData = sendDataJson(requestDataJson, apiUrl)
    return resultData

def sendDataJson(data,apiUrl):
    requestData = data
    host = urlparse.urlparse(apiUrl)
    hostUrl = host.netloc
    hostPath = host.path
    headers = {"Content-type": "application/json"}
    conn = httplib.HTTPSConnection(hostUrl, 443, 0, 0, 0, timeout_connect)
    conn.request("POST", hostPath, requestData, headers)
    readData = conn.getresponse(timeout_read)
    resultData = readData.read()
    return resultData

def sendData(data,apiUrl):
    host = urlparse.urlparse(apiUrl)
    hostUrl = host.netloc
    hostPath = host.path
    params = urllib.urlencode(data)
    headers = {"Content-type": "application/x-www-form-urlencoded"}
    conn = httplib.HTTPSConnection(hostUrl, 443, 0, 0, 0, timeout_connect)
    conn.request("POST", hostPath, params, headers)
    readData = conn.getresponse(timeout_read)
    resultData = readData.read()
    return resultData