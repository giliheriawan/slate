import json

#Import Library (Mandatory)
from Lib import Nicepay

#setMandatoryParameter
Nicepay.set('timeStamp', '20180109181300')
Nicepay.set('tXid', 'IONPAYTEST02201801121146555531')
Nicepay.set('iMid', Nicepay.iMid)
Nicepay.set('referenceNo', 'ADETEST02')
Nicepay.set('amt', '10000')
Nicepay.set('merchantToken', Nicepay.merchantToken())

resultData = Nicepay.niceInquiry()
result = json.loads(resultData)

#Payment Response String Format
try:
    result['resultCd']
except NameError:
    print "Connection Timeout. Please Try Again!"
else:
    if result['resultCd'] == '0000':
        print("resultCd : " + result['resultCd'])
        print("resultMsg : " + result['resultMsg'])
        print("tXid : " + result['tXid'])
        print("iMid : " + result['iMid'])
        print("referenceNo : " + result['referenceNo'])
        print("payMethod : " + result['payMethod'])
        print("amt : " + result['amt'])
        if result['cancelAmt']:
            print("cancelAmt : " + result['cancelAmt'])
        print("reqDt : " + result['reqDt'])
        print("reqTm : " + result['reqTm'])
        print("transDt : " + result['transDt'])
        print("transTm : " + result['transTm'])
        print("currency : " + result['currency'])
        print("goodsNm : " + result['goodsNm'])
        print("billingNm : " + result['billingNm'])
        print("status : " + result['status'])

        if result['payMethod'] == '01':
            print("authNo : " + result['authNo'])
            print("issuBankCd : " + result['issuBankCd'])
            print("acquBankCd : " + result['acquBankCd'])
            print("cardNo : " + result['cardNo'])
            print("cardExpYymm : " + result['cardExpYymm'])
            print("instmntMon : " + result['instmntMon'])
            print("instmntType : " + result['instmntType'])
            print("preauthToken : " + result['preauthToken'])
            print("recurringToken : " + result['recurringToken'])
            print("ccTransType : " + result['ccTransType'])
            print("acquStatus : " + result['acquStatus'])
            print("vat : " + result['vat'])
            print("fee : " + result['fee'])
            print("notaxAmt : " + result['notaxAmt'])
        if result['payMethod'] == '02':
            print("bankCd : " + result['bankCd'])
            print("vacctNo : " + result['vacctNo'])
            print("vacctValidDt : " + result['vacctValidDt'])
            print("vacctValidTm : " + result['vacctValidTm'])
        if result['payMethod'] == '03':
            print("mitraCd : " + result['mitraCd'])
            print("payNo : " + result['payNo'])
            print("payValidDt : " + result['payValidDt'])
            print("payValidTm : " + result['payValidTm'])
        if result['payMethod'] == '04':
            print("mitraCd : " + result['mitraCd'])
            print("receiptCode : " + result['receiptCode'])
            print("mRefNo : " + result['mRefNo'])
        if result['payMethod'] == '05':
            print("mitraCd : " + result['mitraCd'])
    else:
        print("resultCd : " + result['resultCd'])
        print("resultMsg : " + result['resultMsg'])