import json

#Import Library (Mandatory)
from Lib import Nicepay

#setMandatoryParameter
Nicepay.set('timeStamp', '20180109181300')
Nicepay.set('iMid', Nicepay.iMid)
Nicepay.set('payMethod', '02')
Nicepay.set('currency', 'IDR')
Nicepay.set('amt', '10000')
Nicepay.set('referenceNo', 'ADETEST02')
Nicepay.set('goodsNm', 'ADEJULIANTO2')
Nicepay.set('billingNm', 'ADETEST01')
Nicepay.set('billingPhone', '08123456789')
Nicepay.set('billingEmail', 'ADETEST01@GMAIL.COM')
Nicepay.set('billingCity', 'JAKARTA')
Nicepay.set('billingState', 'JAKARTA')
Nicepay.set('billingPostCd', '14350')
Nicepay.set('billingCountry', 'INDONESIA')
Nicepay.set('dbProcessUrl', 'https://hookb.in/vP8bQ289')
Nicepay.set('merchantToken', Nicepay.merchantToken())
Nicepay.set('userIP', Nicepay.userIp())
Nicepay.set('cartData', '{}')

#For Credit Card (Don't forgot change payMethod to '01')
# Nicepay.set('instmntType', '2')
# Nicepay.set('instmntMon', '1')

#For Virtual Account (Don't forgot change payMethod to '02')
Nicepay.set('bankCd', 'BMRI')
Nicepay.set('vacctValidDt', '20180112') #Format (YYYYMMDD)
Nicepay.set('vacctValidTm', '235959') #Format (HHiiss)

#For Credit Card Reccuring Only
# Nicepay.set('recurrOpt', '0')

#For Virtual Account Fix Account
# Nicepay.set('merFixAcctId', '12345679') #length value of merFixAcctId setting By Mid. Contact Nicepay IT for Information

#For CVS,ClickPay or E-Wallet (Don't forgot change payMethod to '03'/'04'/'05')
# Nicepay.set('mitraCd', 'INDO')

#For CVS Only
# Nicepay.set('payValidDt', '20180112') #Format (YYYYMMDD)
# Nicepay.set('payValidTm', '235959') #Format (HHiiss)

#For ClickPay Only
# Nicepay.set('mRefNo', '123441231232123444')


#setOptionalParameter
# Nicepay.set('billingAddr', 'Billing Address')
# Nicepay.set('deliveryNm', 'Buyer Name')
# Nicepay.set('deliveryPhone', '02112345678')
# Nicepay.set('deliveryAddr', 'Billing Address')
# Nicepay.set('deliveryCity', 'Jakarta')
# Nicepay.set('deliveryState', 'Jakarta')
# Nicepay.set('deliveryPostCd', '12345')
# Nicepay.set('deliveryCountry', 'Indonesia')
# Nicepay.set('vat', '0')
# Nicepay.set('fee', '0')
# Nicepay.set('notaxAmt', '0')
# Nicepay.set('description', 'Description')
# Nicepay.set('reqDt', '20160301') #Format (YYYYMMDD)
# Nicepay.set('reqTm', '135959') #Format (HHiiss)
# Nicepay.set('reqDomain', 'merchant.com')
# Nicepay.set('reqServerIP', '127.0.0.1')
# Nicepay.set('reqClientVer', '1.0')
# Nicepay.set('userSessionID', 'userSessionID')
# Nicepay.set('userAgent', 'Mozilla')
# Nicepay.set('userLanguage', 'en-US')



resultData = Nicepay.niceRegister()
print resultData

result = json.loads(resultData)

#Payment Response String Format
try:
    result['resultCd']
except NameError:
    print "Connection Timeout. Please Try Again!"
else:
    if result['resultCd'] == '0000':
        print("resultCd : " + result['resultCd'])
        print("resultMsg : " + result['resultMsg'])
        print("tXid : " + result['tXid'])
        print("referenceNo : " + result['referenceNo'])
        print("payMethod : " + result['payMethod'])
        print("amount : " + result['amt'])
        print("transDt : " + result['transDt'])
        print("transTm : " + result['transTm'])
        if result['goodsNm']:
            print("goodsNm : " + result['goodsNm'])
        if result['billingNm']:
            print("billingNm : " + result['billingNm'])
        if result['currency']:
            print("currency : " + result['currency'])
        elif result['payMethod'] == "02":
            print("bankCd : " + result['bankCd'])
            print("vacctNo : " + result['vacctNo'])
            print("vacctValidDt : " + result['vacctValidDt'])
            print("vacctValidTm : " + result['vacctValidTm'])
        elif result['payMethod'] == "03":
            print("mitraCd : " + result['mitraCd'])
            print("payNo : " + result['payNo'])
            print("vacctValidDt : " + result['payValidDt'])
            print("vacctValidTm : " + result['payValidTm'])
        elif result['payMethod'] == "04":
            print("mitraCd : " + result['mitraCd'])
            print("receiptCode : " + result['receiptCode'])
        elif result['payMethod'] == "05":
            print("mitraCd : " + result['mitraCd'])
            print("receiptCode : " + result['receiptCode'])
    else:
        print("resultCd : " + result['resultCd'])
        print("resultMsg : " + result['resultMsg'])
