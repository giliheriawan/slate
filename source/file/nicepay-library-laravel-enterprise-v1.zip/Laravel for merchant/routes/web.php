<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('nicepay', function () {
    return redirect('VA-Redirect');
});

// Nicepay Redirect

Route::get('/VA-Redirect', 'NicepayController@VARedirect')->name('nicepay');

Route::get('/CVS-Redirect', 'NicepayController@CVSRedirect')->name('nicepay');

Route::get('/CC-Redirect', 'NicepayController@CCRedirect')->name('nicepay');

Route::get('/CC-Installment-Redirect', 'NicepayController@CCInstallmentRedirect')->name('nicepay');

// Nicepay Direct

Route::get('/VA-Direct', 'NicepayController@VADirect')->name('nicepay');

Route::get('/CC-Direct', 'NicepayController@CCDirect')->name('nicepay');

Route::get('/CVS-Direct', 'NicepayController@CVSDirect')->name('nicepay');

Route::get('/Check-Payment-Status', 'NicepayController@CheckPaymentStatus')->name('nicepay');

Route::post('/CheckoutRedirect', [
  'as' => 'CheckoutRedirect', 'uses' => 'NicepayRedirect\CheckoutController@CheckoutRedirect'
]);

Route::post('/CheckoutDirect', [
  'as' => 'CheckoutDirect', 'uses' => 'NicepayDirect\CheckoutController@CheckoutDirect'
]);

Route::post('/CheckPaymentStatus', [
  'as' => 'CheckPaymentStatus', 'uses' => 'NicepayRedirect\OtherFiturController@CheckPaymentStatus'
]);

Route::get('/ThankYou', 'NicepayRedirect\CallPushController@CallBackURL')->name('callpush');

// Route::post('/Notification', [
//   'as' => 'Notification', 'uses' => 'CallPushController@DBProcessURL'
// ]);

// Route::get('/Notification', 'CallPushController@DBProcessURL')->name('callpush');
// Route::match(['POST','GET','REQUEST'], '/Notification', 'CallPushController@DBProcessURL');

Route::post('/Notification', 'NicepayRedirect\CallPushController@DBProcessURL')->name('callpush');
